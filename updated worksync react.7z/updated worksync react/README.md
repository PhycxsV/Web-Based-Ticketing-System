Ticketing System Prototype

To access:

Open the backend in your cmd

'cd C:\Users\User\Desktop\WorkSync'

then, 'npm start' to make the backend work

Open a seperate cmd for your front end

'cd C:\Users\User\Desktop\WorkSync\worksync-react'

then, 'npm start' to open the front end.


Once the frontend is working, you will be directed to a login page

Admin: amielverzola@gmail.com - 123123123

NOTE: amielverzola@gmail.com is the only account with admin control, if you try to create a new account it will only be given the agent role with limited access to the website. I suggest opening the admin account for the full feature.