# WorkSync Frontend

A modern, responsive React TypeScript frontend for the WorkSync ticketing system.

## 🚀 Features

- **Modern UI**: Built with React 18 and TypeScript
- **Responsive Design**: Fully responsive using Tailwind CSS
- **Authentication**: Secure login/logout system
- **Dashboard**: Comprehensive admin dashboard
- **Ticket Management**: Create, view, and manage tickets
- **Company Management**: Manage companies and branches
- **Real-time Notifications**: Toast notifications for user feedback

## 📋 Prerequisites

Before running this application, make sure you have:

- **Node.js** (v14 or higher)
- **npm** (v6 or higher)
- **WorkSync Backend** running on `http://localhost:1337`

## 🛠 Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/worksync.git
   cd worksync/worksync-react
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start the development server**
   ```bash
   npm start
   ```

The application will open at `http://localhost:3000`

## 🌐 Application URLs

- **Frontend**: `http://localhost:3000`
- **Backend API**: `http://localhost:1337`

## 🔐 Default Login

- **Username**: `worksyncmanager`
- **Password**: `123123123`

## 📱 Pages & Routes

- `/login` - User authentication
- `/dashboard` - Main dashboard
- `/tickets` - Ticket management
- `/setup` - System setup and configuration

## 🛠 Available Scripts

- `npm start` - Start development server
- `npm run build` - Build for production
- `npm test` - Run tests
- `npm run eject` - Eject from Create React App

## 🎨 Tech Stack

- **React 18** - Frontend framework
- **TypeScript** - Type safety
- **Tailwind CSS** - Utility-first CSS framework
- **React Router** - Client-side routing
- **React Hot Toast** - Notifications
- **Axios** - HTTP client (implied by API calls)

## 🏗 Project Structure

```
src/
├── components/
│   ├── Auth/
│   ├── Layout/
│   └── ...
├── contexts/
│   └── AuthContext.tsx
├── pages/
│   ├── Dashboard.tsx
│   ├── TicketsPage.tsx
│   └── SetupPage.tsx
├── services/
├── types/
├── App.tsx
├── index.tsx
└── index.css
```

## 🔧 Configuration

### Environment Variables

Create a `.env` file in the root directory:

```env
REACT_APP_API_URL=http://localhost:1337
```

### API Integration

The frontend expects the backend to be running on `http://localhost:1337`. If your backend runs on a different port, update the API configuration in the services folder.

## 🚀 Building for Production

1. **Build the project**
   ```bash
   npm run build
   ```

2. **Serve the built files**
   ```bash
   npx serve -s build
   ```

## 🔧 Troubleshooting

### Common Issues

1. **Backend not running**: Make sure the WorkSync backend is running on port 1337
2. **CORS errors**: Ensure the backend has CORS properly configured
3. **Port conflicts**: Change the development port if 3000 is in use

### Module Resolution Issues

If you encounter module resolution issues:

1. Delete `node_modules` and `package-lock.json`
2. Run `npm install`
3. Restart the development server

## 🌐 Deployment

### Production Deployment

1. **Build the project**: `npm run build`
2. **Deploy the `build` folder** to your hosting service
3. **Configure your web server** to serve `index.html` for all routes

### Popular Hosting Options

- **Netlify**: Drag and drop the `build` folder
- **Vercel**: Connect your GitHub repository
- **GitHub Pages**: Use `gh-pages` package
- **Firebase Hosting**: Use Firebase CLI

## 👥 Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/new-feature`
3. Commit your changes: `git commit -am 'Add new feature'`
4. Push to the branch: `git push origin feature/new-feature`
5. Create a Pull Request

## 📄 License

This project is licensed under the MIT License.

## 🆘 Support

If you encounter any issues:

1. Check the console for error messages
2. Ensure the backend is running
3. Verify all dependencies are installed
4. Create an issue on GitHub with detailed information 