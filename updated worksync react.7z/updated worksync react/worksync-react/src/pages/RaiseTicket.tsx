import React, { useState, useEffect } from 'react';
import Navbar from '../components/Navbar';
import toast from 'react-hot-toast';
import axios from 'axios';
import { useAuth } from '../contexts/AuthContext';

interface TicketFormData {
  title: string;
  priority: string;
  company: string;
  category: string;
  dateRequired: string;
  requestor: string;
  description: string;
  personnel: string[];
  type: string;
}

interface Ticket {
  id: number;
  ticketNumber: string;
  title: string;
  priority: string;
  status: string;
  company: string;
  category: string;
  requestor: string;
  description: string;
  personnel: string[];
  type: string;
  dateRequired: string;
  dateCreated: string;
  dateResolved?: string;
  assignedTo?: number;
}

interface Company {
  id: number;
  name: string;
}

const RaiseTicket: React.FC = () => {
  const { token, user } = useAuth();
  const [activeTab, setActiveTab] = useState(user?.role === 'admin' ? 'create' : 'view');
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState<TicketFormData>({
    title: '',
    priority: 'medium',
    company: '',
    category: 'Technical',
    dateRequired: '',
    requestor: '',
    description: '',
    personnel: [''],
    type: 'personnel_request'
  });

  useEffect(() => {
    fetchCompanies();
    if (activeTab === 'view' || activeTab === 'resolved' || activeTab === 'unresolved') {
      fetchTickets();
    }
  }, [activeTab]);

  const getAuthHeaders = () => ({
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    }
  });

  const fetchCompanies = async () => {
    try {
      const response = await axios.get('http://localhost:1337/api/companies', getAuthHeaders());
      setCompanies(response.data);
    } catch (error) {
      console.error('Error fetching companies:', error);
      toast.error('Failed to load companies');
    }
  };

  const fetchTickets = async () => {
    setLoading(true);
    try {
      const response = await axios.get('http://localhost:1337/api/tickets', getAuthHeaders());
      
      // Ensure all tickets have a status (default to 'open' if not set)
      const ticketsWithStatus = response.data.map((ticket: any) => ({
        ...ticket,
        status: ticket.status || 'open'
      }));
      
      setTickets(ticketsWithStatus);
    } catch (error) {
      console.error('Error fetching tickets:', error);
      toast.error('Failed to load tickets');
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handlePersonnelChange = (index: number, value: string) => {
    const newPersonnel = [...formData.personnel];
    newPersonnel[index] = value;
    setFormData(prev => ({
      ...prev,
      personnel: newPersonnel
    }));
  };

  const addPersonnelField = () => {
    setFormData(prev => ({
      ...prev,
      personnel: [...prev.personnel, '']
    }));
  };

  const removePersonnelField = (index: number) => {
    const newPersonnel = formData.personnel.filter((_, i) => i !== index);
    setFormData(prev => ({
      ...prev,
      personnel: newPersonnel
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const response = await axios.post('http://localhost:1337/api/tickets', formData, getAuthHeaders());
      
      if (response.status === 201) {
        toast.success('Ticket created successfully!');
        
        // Reset form
        setFormData({
          title: '',
          priority: 'medium',
          company: '',
          category: 'Technical',
          dateRequired: '',
          requestor: '',
          description: '',
          personnel: [''],
          type: 'personnel_request'
        });
        
        // Refresh tickets list
        await fetchTickets();
        
        // Switch to view tab to see the new ticket
        setActiveTab('view');
      }
    } catch (error) {
      console.error('Error creating ticket:', error);
      toast.error('Failed to create ticket. Please try again.');
    }
  };

  const handleStatusChange = async (ticketId: number, newStatus: string) => {
    try {
      await axios.put(`http://localhost:1337/api/tickets/${ticketId}`, 
        { status: newStatus }, 
        getAuthHeaders()
      );
      
      const statusMessage = newStatus === 'resolved' ? 'Ticket marked as resolved!' : 'Ticket reopened!';
      toast.success(statusMessage);
      
      // Refresh tickets list to show updated status
      await fetchTickets();
    } catch (error) {
      console.error('Error updating ticket status:', error);
      toast.error('Failed to update ticket status. Please try again.');
    }
  };

  const viewTicket = (ticket: Ticket) => {
    setSelectedTicket(ticket);
    setShowModal(true);
  };

  const handleDeleteTicket = async (ticketId: number) => {
    if (user?.role !== 'admin') {
      toast.error('Only administrators can delete tickets');
      return;
    }
    
    if (window.confirm('Are you sure you want to delete this ticket? This action cannot be undone.')) {
      try {
        await axios.delete(`http://localhost:1337/api/tickets/${ticketId}`, getAuthHeaders());
        toast.success('Ticket deleted successfully!');
        await fetchTickets();
      } catch (error) {
        console.error('Error deleting ticket:', error);
        toast.error('Failed to delete ticket. Please try again.');
      }
    }
  };

  // Filter tickets based on active tab
  const getFilteredTickets = () => {
    switch (activeTab) {
      case 'resolved':
        return tickets.filter(ticket => ticket.status === 'resolved' || ticket.status === 'closed');
      case 'unresolved':
        return tickets.filter(ticket => ticket.status === 'open' || ticket.status === 'in-progress');
      case 'view':
      default:
        return tickets;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'text-danger';
      case 'medium': return 'text-warning';
      case 'low': return 'text-success';
      default: return 'text-secondary';
    }
  };

  const getStatusBadge = (status: string) => {
    const badgeClasses = {
      'open': 'bg-warning text-dark',
      'in-progress': 'bg-info text-white',
      'resolved': 'bg-success text-white',
      'closed': 'bg-secondary text-white'
    };
    return badgeClasses[status as keyof typeof badgeClasses] || 'bg-secondary text-white';
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <main style={{ backgroundColor: '#f8f9fa', minHeight: '100vh' }}>
      <Navbar />
      
      {/* Page Header */}
      <div className="page-header" style={{ background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', color: 'white', padding: '2rem 0', marginBottom: '2rem' }}>
        <div className="container">
          <h1 className="mb-0">Ticket Management</h1>
          <p className="mb-0">Create and manage support tickets</p>
        </div>
      </div>

      <div className="container">
        {/* Tab Navigation */}
        <ul className="nav nav-pills form-tabs mb-4" style={{ borderBottom: '2px solid #dee2e6' }}>
          {/* Create tab - admin only */}
          {user?.role === 'admin' && (
            <li className="nav-item">
              <button
                className={`nav-link ${activeTab === 'create' ? 'active' : ''}`}
                onClick={() => setActiveTab('create')}
                style={{ border: 'none', borderBottom: activeTab === 'create' ? '3px solid #007bff' : '3px solid transparent', borderRadius: 0, padding: '1rem 1.5rem', fontWeight: 500, background: 'none' }}
              >
                <i className="fas fa-plus me-2"></i>Create Ticket
              </button>
            </li>
          )}
          
          <li className="nav-item">
            <button
              className={`nav-link ${activeTab === 'view' ? 'active' : ''}`}
              onClick={() => setActiveTab('view')}
              style={{ border: 'none', borderBottom: activeTab === 'view' ? '3px solid #007bff' : '3px solid transparent', borderRadius: 0, padding: '1rem 1.5rem', fontWeight: 500, background: 'none' }}
            >
              <i className="fas fa-list me-2"></i>All Tickets
            </button>
          </li>
          
          <li className="nav-item">
            <button
              className={`nav-link ${activeTab === 'unresolved' ? 'active' : ''}`}
              onClick={() => setActiveTab('unresolved')}
              style={{ border: 'none', borderBottom: activeTab === 'unresolved' ? '3px solid #007bff' : '3px solid transparent', borderRadius: 0, padding: '1rem 1.5rem', fontWeight: 500, background: 'none' }}
            >
              <i className="fas fa-clock me-2"></i>Unresolved
            </button>
          </li>
          
          <li className="nav-item">
            <button
              className={`nav-link ${activeTab === 'resolved' ? 'active' : ''}`}
              onClick={() => setActiveTab('resolved')}
              style={{ border: 'none', borderBottom: activeTab === 'resolved' ? '3px solid #007bff' : '3px solid transparent', borderRadius: 0, padding: '1rem 1.5rem', fontWeight: 500, background: 'none' }}
            >
              <i className="fas fa-check-circle me-2"></i>Resolved
            </button>
          </li>
        </ul>

        {/* Create Ticket Tab - Admin Only */}
        {activeTab === 'create' && user?.role === 'admin' && (
          <div className="content-card" style={{ background: 'white', borderRadius: '12px', boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)', padding: '2rem', marginBottom: '2rem' }}>
            <h5 className="mb-4">
              <i className="fas fa-ticket-alt me-2"></i>Create New Ticket
            </h5>

        {/* Access Denied Message for Agents */}
        {activeTab === 'create' && user?.role !== 'admin' && (
          <div className="content-card" style={{ background: 'white', borderRadius: '12px', boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)', padding: '2rem', marginBottom: '2rem' }}>
            <div className="text-center py-5">
              <i className="fas fa-lock fa-3x text-warning mb-3"></i>
              <h5 className="text-muted">Access Restricted</h5>
              <p className="text-muted">
                Only administrators can create new tickets. As an agent, you can view and track existing tickets.
              </p>
              <button 
                className="btn btn-primary"
                onClick={() => setActiveTab('view')}
              >
                <i className="fas fa-list me-2"></i>View All Tickets
              </button>
            </div>
          </div>
        )}

            <form onSubmit={handleSubmit} className="ticket-form">
              <div className="row mb-3">
                <div className="col-md-6">
                  <label className="form-label">Ticket Type</label>
                  <select
                    className="form-select"
                    name="type"
                    value={formData.type}
                    onChange={handleInputChange}
                    style={{ borderRadius: '8px', border: '1px solid #dee2e6', padding: '0.75rem 1rem' }}
                  >
                    <option value="personnel_request">Personnel Request</option>
                    <option value="technical_support">Technical Support</option>
                    <option value="maintenance">Maintenance</option>
                    <option value="general_inquiry">General Inquiry</option>
                  </select>
                </div>
                <div className="col-md-6">
                  <label className="form-label">Priority</label>
                  <select
                    className="form-select"
                    name="priority"
                    value={formData.priority}
                    onChange={handleInputChange}
                    style={{ borderRadius: '8px', border: '1px solid #dee2e6', padding: '0.75rem 1rem' }}
                  >
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                  </select>
                </div>
              </div>

              <div className="row mb-3">
                <div className="col-md-6">
                  <label className="form-label">Title</label>
                  <input
                    type="text"
                    className="form-control"
                    name="title"
                    value={formData.title}
                    onChange={handleInputChange}
                    style={{ borderRadius: '8px', border: '1px solid #dee2e6', padding: '0.75rem 1rem' }}
                    required
                  />
                </div>
                <div className="col-md-6">
                  <label className="form-label">Company</label>
                  <select
                    className="form-select"
                    name="company"
                    value={formData.company}
                    onChange={handleInputChange}
                    style={{ borderRadius: '8px', border: '1px solid #dee2e6', padding: '0.75rem 1rem' }}
                    required
                  >
                    <option value="">Select Company</option>
                    {companies.map(company => (
                      <option key={company.id} value={company.id}>{company.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="row mb-3">
                <div className="col-md-6">
                  <label className="form-label">Category</label>
                  <select
                    className="form-select"
                    name="category"
                    value={formData.category}
                    onChange={handleInputChange}
                    style={{ borderRadius: '8px', border: '1px solid #dee2e6', padding: '0.75rem 1rem' }}
                  >
                    <option value="Technical">Technical</option>
                    <option value="Administrative">Administrative</option>
                    <option value="Human Resources">Human Resources</option>
                    <option value="Finance">Finance</option>
                  </select>
                </div>
                <div className="col-md-6">
                  <label className="form-label">Date Required</label>
                  <input
                    type="date"
                    className="form-control"
                    name="dateRequired"
                    value={formData.dateRequired}
                    onChange={handleInputChange}
                    style={{ borderRadius: '8px', border: '1px solid #dee2e6', padding: '0.75rem 1rem' }}
                    required
                  />
                </div>
              </div>

              <div className="mb-3">
                <label className="form-label">Requestor</label>
                <input
                  type="text"
                  className="form-control"
                  name="requestor"
                  value={formData.requestor}
                  onChange={handleInputChange}
                  placeholder="Full Name of Requestor"
                  style={{ borderRadius: '8px', border: '1px solid #dee2e6', padding: '0.75rem 1rem' }}
                  required
                />
              </div>

              <div className="mb-3">
                <label className="form-label">Personnel Required</label>
                {formData.personnel.map((person, index) => (
                  <div key={index} className="d-flex gap-2 mb-2">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Last Name, First Name"
                      value={person}
                      onChange={(e) => handlePersonnelChange(index, e.target.value)}
                      style={{ borderRadius: '8px', border: '1px solid #dee2e6', padding: '0.75rem 1rem' }}
                      required
                    />
                    {formData.personnel.length > 1 && (
                      <button
                        type="button"
                        className="btn btn-outline-danger"
                        onClick={() => removePersonnelField(index)}
                        style={{ width: '44px' }}
                      >
                        <i className="fas fa-trash"></i>
                      </button>
                    )}
                  </div>
                ))}
                <button
                  type="button"
                  className="btn btn-outline-primary btn-sm"
                  onClick={addPersonnelField}
                >
                  <i className="fas fa-plus me-2"></i>Add More Personnel
                </button>
              </div>

              <div className="mb-3">
                <label className="form-label">Description</label>
                <textarea
                  className="form-control"
                  name="description"
                  rows={4}
                  value={formData.description}
                  onChange={handleInputChange}
                  placeholder="Provide detailed description of the request..."
                  style={{ borderRadius: '8px', border: '1px solid #dee2e6', padding: '0.75rem 1rem' }}
                  required
                ></textarea>
              </div>

              <div className="text-end">
                <button
                  type="submit"
                  className="btn btn-primary"
                  style={{ background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', border: 'none', borderRadius: '8px', padding: '0.75rem 2rem', fontWeight: 500 }}
                >
                  <i className="fas fa-paper-plane me-2"></i>Submit Ticket
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Tickets Tabs (All, Resolved, Unresolved) */}
        {(activeTab === 'view' || activeTab === 'resolved' || activeTab === 'unresolved') && (
          <div className="tickets-table" style={{ background: 'white', borderRadius: '12px', boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)', overflow: 'hidden' }}>
            <div className="table-header d-flex justify-content-between align-items-center" style={{ background: '#f8f9fa', padding: '1rem 1.5rem', borderBottom: '1px solid #dee2e6', fontWeight: 600 }}>
              <div>
                <i className={`fas ${activeTab === 'resolved' ? 'fa-check-circle' : activeTab === 'unresolved' ? 'fa-clock' : 'fa-list'} me-2`}></i>
                {activeTab === 'resolved' ? 'Resolved Tickets' : activeTab === 'unresolved' ? 'Unresolved Tickets' : 'All Tickets'} ({getFilteredTickets().length})
              </div>
              <button 
                className="btn btn-sm btn-primary"
                onClick={fetchTickets}
                disabled={loading}
              >
                <i className="fas fa-sync me-1"></i>
                {loading ? 'Loading...' : 'Refresh'}
              </button>
            </div>
            
            {loading ? (
              <div className="text-center p-4">
                <div className="spinner-border text-primary" role="status">
                  <span className="visually-hidden">Loading...</span>
                </div>
              </div>
            ) : (
              <div className="table-responsive">
                <table className="table table-hover mb-0">
                  <thead>
                    <tr>
                      <th>Ticket #</th>
                      <th>Title</th>
                      <th>Priority</th>
                      <th>Status</th>
                      <th>Company</th>
                      <th>Date Created</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {getFilteredTickets().length === 0 ? (
                      <tr>
                        <td colSpan={7} className="text-center py-4 text-muted">
                          <i className="fas fa-inbox fa-2x mb-3 d-block"></i>
                          {activeTab === 'resolved' ? 'No resolved tickets found.' : 
                           activeTab === 'unresolved' ? 'No unresolved tickets found.' : 
                           'No tickets found. Create your first ticket!'}
                        </td>
                      </tr>
                    ) : (
                      getFilteredTickets().map(ticket => (
                        <tr key={ticket.id}>
                          <td className="fw-bold">{ticket.ticketNumber}</td>
                          <td>{ticket.title}</td>
                          <td>
                            <span className={getPriorityColor(ticket.priority)}>
                              <i className="fas fa-circle me-1" style={{ fontSize: '0.5rem' }}></i>
                              {ticket.priority}
                            </span>
                          </td>
                          <td>
                            <span className={`badge ${getStatusBadge(ticket.status)}`}>
                              {ticket.status.replace('-', ' ')}
                            </span>
                          </td>
                          <td>{companies.find(c => c.id.toString() === ticket.company)?.name || 'Unknown'}</td>
                          <td>{formatDate(ticket.dateCreated)}</td>
                          <td>
                            <button 
                              className="btn btn-sm btn-outline-primary me-1"
                              onClick={() => viewTicket(ticket)}
                              title="View Details"
                            >
                              <i className="fas fa-eye"></i>
                            </button>
                            
                            {/* Status change buttons - available to all users */}
                            {ticket.status !== 'resolved' ? (
                              <button 
                                className="btn btn-sm btn-outline-success me-1"
                                onClick={() => handleStatusChange(ticket.id, 'resolved')}
                                title="Mark as Resolved"
                              >
                                <i className="fas fa-check"></i>
                              </button>
                            ) : (
                              <button 
                                className="btn btn-sm btn-outline-warning me-1"
                                onClick={() => handleStatusChange(ticket.id, 'open')}
                                title="Reopen Ticket"
                              >
                                <i className="fas fa-undo"></i>
                              </button>
                            )}
                            
                            {/* Admin-only delete button */}
                            {user?.role === 'admin' && (
                              <button 
                                className="btn btn-sm btn-outline-danger"
                                onClick={() => handleDeleteTicket(ticket.id)}
                                title="Delete Ticket (Admin Only)"
                              >
                                <i className="fas fa-trash"></i>
                              </button>
                            )}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Ticket Detail Modal */}
      {showModal && selectedTicket && (
        <div className="modal fade show" style={{ display: 'block', backgroundColor: 'rgba(0,0,0,0.5)' }} onClick={() => setShowModal(false)}>
          <div className="modal-dialog modal-lg" onClick={(e) => e.stopPropagation()}>
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">
                  <i className="fas fa-ticket-alt me-2"></i>
                  Ticket Details - {selectedTicket.ticketNumber}
                </h5>
                <button type="button" className="btn-close" onClick={() => setShowModal(false)}></button>
              </div>
              <div className="modal-body">
                <div className="row mb-3">
                  <div className="col-md-6">
                    <strong>Status:</strong>
                    <span className={`badge ${getStatusBadge(selectedTicket.status)} ms-2`}>
                      {selectedTicket.status.replace('-', ' ')}
                    </span>
                  </div>
                  <div className="col-md-6">
                    <strong>Priority:</strong>
                    <span className={`ms-2 ${getPriorityColor(selectedTicket.priority)}`}>
                      <i className="fas fa-circle me-1" style={{ fontSize: '0.5rem' }}></i>
                      {selectedTicket.priority}
                    </span>
                  </div>
                </div>
                <div className="row mb-3">
                  <div className="col-md-6">
                    <strong>Company:</strong> {companies.find(c => c.id.toString() === selectedTicket.company)?.name || 'Unknown'}
                  </div>
                  <div className="col-md-6">
                    <strong>Category:</strong> {selectedTicket.category}
                  </div>
                </div>
                <div className="row mb-3">
                  <div className="col-md-6">
                    <strong>Requestor:</strong> {selectedTicket.requestor}
                  </div>
                  <div className="col-md-6">
                    <strong>Type:</strong> {selectedTicket.type.replace('_', ' ')}
                  </div>
                </div>
                <div className="row mb-3">
                  <div className="col-md-6">
                    <strong>Date Required:</strong> {new Date(selectedTicket.dateRequired).toLocaleDateString()}
                  </div>
                  <div className="col-md-6">
                    <strong>Date Created:</strong> {formatDate(selectedTicket.dateCreated)}
                  </div>
                </div>
                <div className="mb-3">
                  <strong>Personnel Required:</strong>
                  <ul className="list-unstyled ms-3">
                    {selectedTicket.personnel.map((person, index) => (
                      <li key={index}>• {person}</li>
                    ))}
                  </ul>
                </div>
                <div className="mb-3">
                  <strong>Description:</strong>
                  <div className="mt-2 p-3" style={{ background: '#f8f9fa', borderRadius: '8px' }}>
                    {selectedTicket.description}
                  </div>
                </div>
              </div>
              <div className="modal-footer">
                {/* Status change buttons - available to all users */}
                {selectedTicket.status !== 'resolved' ? (
                  <button 
                    className="btn btn-success"
                    onClick={() => {
                      handleStatusChange(selectedTicket.id, 'resolved');
                      setShowModal(false);
                    }}
                  >
                    <i className="fas fa-check me-2"></i>Mark as Resolved
                  </button>
                ) : (
                  <button 
                    className="btn btn-warning"
                    onClick={() => {
                      handleStatusChange(selectedTicket.id, 'open');
                      setShowModal(false);
                    }}
                  >
                    <i className="fas fa-undo me-2"></i>Reopen Ticket
                  </button>
                )}
                
                {/* Admin-only delete button */}
                {user?.role === 'admin' && (
                  <button 
                    className="btn btn-danger"
                    onClick={() => {
                      handleDeleteTicket(selectedTicket.id);
                      setShowModal(false);
                    }}
                  >
                    <i className="fas fa-trash me-2"></i>Delete Ticket (Admin Only)
                  </button>
                )}
                
                <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </main>
  );
};

export default RaiseTicket; 