import React, { useState, useEffect } from 'react';
import Navbar from '../components/Navbar';
import toast from 'react-hot-toast';
import axios from 'axios';
import { useAuth } from '../contexts/AuthContext';

interface Company {
  id: number;
  name: string;
  industry: string;
  contactPerson: string;
  phone: string;
  email: string;
  website: string;
  address: string;
  dateAdded: string;
}

interface Branch {
  id: number;
  name: string;
  companyId: number;
  address: string;
  contactPerson: string;
  phone: string;
  email: string;
}

interface User {
  id: number;
  username: string;
  email: string;
  firstName: string;
  lastName: string;
  role: string;
  department: string;
  isActive: boolean;
}

const Setup: React.FC = () => {
  const { token, user: currentUser } = useAuth();
  const [activeTab, setActiveTab] = useState('companies');
  const [companies, setCompanies] = useState<Company[]>([]);
  const [branches, setBranches] = useState<Branch[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [modalType, setModalType] = useState('');
  const [editingItem, setEditingItem] = useState<any>(null);
  


  const [formData, setFormData] = useState({
    // Company fields
    name: '',
    industry: '',
    contactPerson: '',
    phone: '',
    email: '',
    website: '',
    address: '',
    
    // Branch fields
    branchName: '',
    companyId: '',
    branchAddress: '',
    branchContactPerson: '',
    branchPhone: '',
    branchEmail: '',
    
    // User fields
    username: '',
    userEmail: '',
    firstName: '',
    lastName: '',
    role: 'agent',
    department: '',
    password: ''
  });

  useEffect(() => {
    // Redirect non-admin users away from Setup page entirely
    if (currentUser && currentUser.role !== 'admin') {
      window.location.href = '/dashboard';
      toast.error('Access denied: Setup is restricted to administrators only.');
      return;
    }
    
    // Redirect non-admin users away from users tab
    if (activeTab === 'users' && currentUser?.role !== 'admin') {
      setActiveTab('companies');
      toast.error('Access denied: User management is restricted to administrators only.');
      return;
    }
    fetchData();
  }, [activeTab, currentUser]);

  const getAuthHeaders = () => ({
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    }
  });

  const fetchData = async () => {
    setLoading(true);
    try {
      if (activeTab === 'companies') {
        await fetchCompanies();
      } else if (activeTab === 'branches') {
        await fetchBranches();
      } else if (activeTab === 'users') {
        await fetchUsers();
      }
    } catch (error) {
      console.error('Error fetching data:', error);
      toast.error('Failed to load data');
    } finally {
      setLoading(false);
    }
  };

  const fetchCompanies = async () => {
    try {
      const response = await axios.get('http://localhost:1337/api/companies', getAuthHeaders());
      setCompanies(response.data);
    } catch (error) {
      console.error('Error fetching companies:', error);
      toast.error('Failed to load companies');
    }
  };

  const fetchBranches = async () => {
    try {
      const response = await axios.get('http://localhost:1337/api/branches', getAuthHeaders());
      setBranches(response.data);
      // Also fetch companies for the dropdown
      if (companies.length === 0) {
        await fetchCompanies();
      }
    } catch (error) {
      console.error('Error fetching branches:', error);
      toast.error('Failed to load branches');
    }
  };

  const fetchUsers = async () => {
    try {
      const response = await axios.get('http://localhost:1337/api/users', getAuthHeaders());
      setUsers(response.data);
    } catch (error) {
      console.error('Error fetching users:', error);
      toast.error('Failed to load users');
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const openModal = (type: string, item?: any) => {
    setModalType(type);
    setEditingItem(item);
    if (item) {
      // Pre-fill form for editing
      if (type === 'company') {
        setFormData({
          ...formData,
          name: item.name || '',
          industry: item.industry || '',
          contactPerson: item.contactPerson || '',
          phone: item.phone || '',
          email: item.email || '',
          website: item.website || '',
          address: item.address || ''
        });
      } else if (type === 'branch') {
        setFormData({
          ...formData,
          branchName: item.name || '',
          companyId: item.companyId?.toString() || '',
          branchAddress: item.address || '',
          branchContactPerson: item.contactPerson || '',
          branchPhone: item.phone || '',
          branchEmail: item.email || ''
        });
      } else if (type === 'user') {
        setFormData({
          ...formData,
          username: item.username || '',
          userEmail: item.email || '',
          firstName: item.firstName || '',
          lastName: item.lastName || '',
          role: item.role || 'agent',
          department: item.department || '',
          password: '' // Don't pre-fill password
        });
      }
    } else {
      // Clear form for new item
      setFormData({
        name: '',
        industry: '',
        contactPerson: '',
        phone: '',
        email: '',
        website: '',
        address: '',
        branchName: '',
        companyId: '',
        branchAddress: '',
        branchContactPerson: '',
        branchPhone: '',
        branchEmail: '',
        username: '',
        userEmail: '',
        firstName: '',
        lastName: '',
        role: 'agent',
        department: '',
        password: ''
      });
    }
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setEditingItem(null);
    setModalType('');
  };



  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      if (modalType === 'company') {
        const companyData = {
          name: formData.name,
          industry: formData.industry,
          contactPerson: formData.contactPerson,
          phone: formData.phone,
          email: formData.email,
          website: formData.website,
          address: formData.address
        };

        if (editingItem) {
          await axios.put(`http://localhost:1337/api/companies/${editingItem.id}`, companyData, getAuthHeaders());
          toast.success('Company updated successfully!');
        } else {
          await axios.post('http://localhost:1337/api/companies', companyData, getAuthHeaders());
          toast.success('Company created successfully!');
        }
        await fetchCompanies();
        
      } else if (modalType === 'branch') {
        const branchData = {
          name: formData.branchName,
          companyId: parseInt(formData.companyId),
          address: formData.branchAddress,
          contactPerson: formData.branchContactPerson,
          phone: formData.branchPhone,
          email: formData.branchEmail
        };

        if (editingItem) {
          await axios.put(`http://localhost:1337/api/branches/${editingItem.id}`, branchData, getAuthHeaders());
          toast.success('Branch updated successfully!');
        } else {
          await axios.post('http://localhost:1337/api/branches', branchData, getAuthHeaders());
          toast.success('Branch created successfully!');
        }
        await fetchBranches();
        
      } else if (modalType === 'user') {
        const userData = {
          username: formData.username,
          email: formData.userEmail,
          firstName: formData.firstName,
          lastName: formData.lastName,
          role: formData.role,
          department: formData.department,
          ...(formData.password && { password: formData.password }) // Only include password if provided
        };

        if (editingItem) {
          await axios.put(`http://localhost:1337/api/users/${editingItem.id}`, userData, getAuthHeaders());
          toast.success('User updated successfully!');
        } else {
          if (!formData.password) {
            toast.error('Password is required for new users');
            return;
          }
          await axios.post('http://localhost:1337/api/auth/local/register', userData);
          toast.success('User created successfully!');
        }
        await fetchUsers();
      }
      
      closeModal();
    } catch (error: any) {
      console.error('Error saving data:', error);
      toast.error(error.response?.data?.message || `Failed to ${editingItem ? 'update' : 'create'} ${modalType}`);
    } finally {
      setLoading(false);
    }
  };

  const handleRoleChange = async (userId: number, newRole: string) => {
    if (window.confirm(`Are you sure you want to change this user's role to ${newRole}?`)) {
      try {
        await axios.put(`http://localhost:1337/api/users/${userId}/role`, 
          { role: newRole }, 
          getAuthHeaders()
        );
        toast.success(`User role updated to ${newRole} successfully!`);
        await fetchUsers();
      } catch (error: any) {
        console.error('Error updating role:', error);
        toast.error(error.response?.data?.message || 'Failed to update user role');
      }
    }
  };

  const handleDelete = async (type: string, id: number) => {
    if (window.confirm(`Are you sure you want to delete this ${type}?`)) {
      try {
        if (type === 'company') {
          await axios.delete(`http://localhost:1337/api/companies/${id}`, getAuthHeaders());
          toast.success('Company deleted successfully!');
          await fetchCompanies();
        } else if (type === 'branch') {
          await axios.delete(`http://localhost:1337/api/branches/${id}`, getAuthHeaders());
          toast.success('Branch deleted successfully!');
          await fetchBranches();
        } else if (type === 'user') {
          await axios.delete(`http://localhost:1337/api/users/${id}`, getAuthHeaders());
          toast.success('User deleted successfully!');
          await fetchUsers();
        }
      } catch (error: any) {
        console.error('Error deleting:', error);
        toast.error(error.response?.data?.message || `Failed to delete ${type}`);
      }
    }
  };

  return (
    <main style={{ backgroundColor: '#f8f9fa', minHeight: '100vh' }}>
      <Navbar />
      
      {/* Page Header */}
      <div className="page-header" style={{ background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', color: 'white', padding: '2rem 0', marginBottom: '2rem' }}>
        <div className="container">
          <h1 className="mb-0">System Setup</h1>
          <p className="mb-0">Manage companies, branches, and users</p>
        </div>
      </div>

      <div className="container">
        {/* Tab Navigation */}
        <div className="setup-tabs mb-4">
          <ul className="nav nav-pills">
            <li className="nav-item">
              <button
                className={`nav-link ${activeTab === 'companies' ? 'active' : ''}`}
                onClick={() => setActiveTab('companies')}
                style={{ borderRadius: '8px', padding: '0.75rem 1.5rem', marginRight: '0.5rem', border: '1px solid #dee2e6', color: activeTab === 'companies' ? 'white' : '#495057', background: activeTab === 'companies' ? 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' : 'white' }}
              >
                <i className="fas fa-building me-2"></i>Companies ({companies.length})
              </button>
            </li>
            <li className="nav-item">
              <button
                className={`nav-link ${activeTab === 'branches' ? 'active' : ''}`}
                onClick={() => setActiveTab('branches')}
                style={{ borderRadius: '8px', padding: '0.75rem 1.5rem', marginRight: '0.5rem', border: '1px solid #dee2e6', color: activeTab === 'branches' ? 'white' : '#495057', background: activeTab === 'branches' ? 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' : 'white' }}
              >
                <i className="fas fa-code-branch me-2"></i>Branches ({branches.length})
              </button>
            </li>
            {/* Users tab - only visible to admin users */}
            {currentUser?.role === 'admin' && (
              <li className="nav-item">
                <button
                  className={`nav-link ${activeTab === 'users' ? 'active' : ''}`}
                  onClick={() => setActiveTab('users')}
                  style={{ borderRadius: '8px', padding: '0.75rem 1.5rem', marginRight: '0.5rem', border: '1px solid #dee2e6', color: activeTab === 'users' ? 'white' : '#495057', background: activeTab === 'users' ? 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' : 'white' }}
                >
                  <i className="fas fa-users me-2"></i>Users ({users.length})
                </button>
              </li>
            )}
          </ul>
        </div>

        {/* Loading State */}
        {loading && (
          <div className="text-center p-4">
            <div className="spinner-border text-primary" role="status">
              <span className="visually-hidden">Loading...</span>
            </div>
          </div>
        )}

        {/* Companies Tab */}
        {activeTab === 'companies' && !loading && (
          <div className="content-card" style={{ background: 'white', borderRadius: '12px', boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)', padding: '2rem', marginBottom: '2rem' }}>
            <div className="d-flex justify-content-between align-items-center mb-4">
              <h5><i className="fas fa-building me-2"></i>Company Management</h5>
              <div>
                <button
                  className="btn btn-outline-primary me-2"
                  onClick={() => fetchCompanies()}
                >
                  <i className="fas fa-sync me-1"></i>Refresh
                </button>
                <button
                  className="btn btn-primary"
                  onClick={() => openModal('company')}
                  style={{ background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', border: 'none', borderRadius: '8px', padding: '0.75rem 2rem', fontWeight: 500 }}
                >
                  <i className="fas fa-plus me-2"></i>Add Company
                </button>
              </div>
            </div>

            <div className="table-responsive">
              <table className="table table-hover">
                <thead>
                  <tr>
                    <th>Company Name</th>
                    <th>Industry</th>
                    <th>Contact Person</th>
                    <th>Phone</th>
                    <th>Email</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {companies.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="text-center py-4 text-muted">
                        <i className="fas fa-building fa-2x mb-3 d-block"></i>
                        No companies found. Add your first company!
                      </td>
                    </tr>
                  ) : (
                    companies.map(company => (
                      <tr key={company.id}>
                        <td className="fw-bold">{company.name}</td>
                        <td>{company.industry}</td>
                        <td>{company.contactPerson}</td>
                        <td>{company.phone}</td>
                        <td>{company.email}</td>
                        <td>
                          <button
                            className="btn btn-sm btn-outline-warning me-2"
                            onClick={() => openModal('company', company)}
                            title="Edit Company"
                          >
                            <i className="fas fa-edit"></i>
                          </button>
                          <button
                            className="btn btn-sm btn-outline-danger"
                            onClick={() => handleDelete('company', company.id)}
                            title="Delete Company"
                          >
                            <i className="fas fa-trash"></i>
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Branches Tab */}
        {activeTab === 'branches' && !loading && (
          <div className="content-card" style={{ background: 'white', borderRadius: '12px', boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)', padding: '2rem', marginBottom: '2rem' }}>
            <div className="d-flex justify-content-between align-items-center mb-4">
              <h5><i className="fas fa-code-branch me-2"></i>Branch Management</h5>
              <div>
                <button
                  className="btn btn-outline-primary me-2"
                  onClick={() => fetchBranches()}
                >
                  <i className="fas fa-sync me-1"></i>Refresh
                </button>
                <button
                  className="btn btn-primary"
                  onClick={() => openModal('branch')}
                  style={{ background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', border: 'none', borderRadius: '8px', padding: '0.75rem 2rem', fontWeight: 500 }}
                >
                  <i className="fas fa-plus me-2"></i>Add Branch
                </button>
              </div>
            </div>

            <div className="table-responsive">
              <table className="table table-hover">
                <thead>
                  <tr>
                    <th>Branch Name</th>
                    <th>Company</th>
                    <th>Address</th>
                    <th>Contact Person</th>
                    <th>Phone</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {branches.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="text-center py-4 text-muted">
                        <i className="fas fa-code-branch fa-2x mb-3 d-block"></i>
                        No branches found. Add your first branch!
                      </td>
                    </tr>
                  ) : (
                    branches.map(branch => (
                      <tr key={branch.id}>
                        <td className="fw-bold">{branch.name}</td>
                        <td>{companies.find(c => c.id === branch.companyId)?.name || 'Unknown'}</td>
                        <td>{branch.address}</td>
                        <td>{branch.contactPerson}</td>
                        <td>{branch.phone}</td>
                        <td>
                          <button
                            className="btn btn-sm btn-outline-warning me-2"
                            onClick={() => openModal('branch', branch)}
                            title="Edit Branch"
                          >
                            <i className="fas fa-edit"></i>
                          </button>
                          <button
                            className="btn btn-sm btn-outline-danger"
                            onClick={() => handleDelete('branch', branch.id)}
                            title="Delete Branch"
                          >
                            <i className="fas fa-trash"></i>
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Users Tab - Admin Only */}
        {activeTab === 'users' && !loading && currentUser?.role === 'admin' && (
          <div className="content-card" style={{ background: 'white', borderRadius: '12px', boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)', padding: '2rem', marginBottom: '2rem' }}>
            <div className="d-flex justify-content-between align-items-center mb-4">
              <div>
                <h5><i className="fas fa-users me-2"></i>User Management</h5>
                <small className="text-muted">
                  <i className="fas fa-info-circle me-1"></i>
                  All accounts created via registration appear here. Only <strong>amielverzola@gmail.com</strong> has admin privileges by default.
                </small>
              </div>
              <div>
                <button
                  className="btn btn-outline-primary me-2"
                  onClick={() => fetchUsers()}
                >
                  <i className="fas fa-sync me-1"></i>Refresh
                </button>
                <button
                  className="btn btn-primary"
                  onClick={() => openModal('user')}
                  style={{ background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', border: 'none', borderRadius: '8px', padding: '0.75rem 2rem', fontWeight: 500 }}
                >
                  <i className="fas fa-plus me-2"></i>Add User
                </button>
              </div>
            </div>

            <div className="table-responsive">
              <table className="table table-hover">
                <thead>
                  <tr>
                    <th>Username</th>
                    <th>Full Name</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Department</th>
                    <th>Status</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {users.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="text-center py-4 text-muted">
                        <i className="fas fa-users fa-2x mb-3 d-block"></i>
                        No users found. Add your first user!
                      </td>
                    </tr>
                  ) : (
                    users.map(user => (
                      <tr key={user.id}>
                        <td className="fw-bold">{user.username}</td>
                        <td>{user.firstName} {user.lastName}</td>
                        <td>{user.email}</td>
                        <td>
                          <span className={`badge ${user.role === 'admin' ? 'bg-danger' : 'bg-primary'}`}>
                            {user.role}
                          </span>
                        </td>
                        <td>{user.department}</td>
                        <td>
                          <span className={`badge ${user.isActive ? 'bg-success' : 'bg-secondary'}`}>
                            {user.isActive ? 'Active' : 'Inactive'}
                          </span>
                        </td>
                        <td>
                          <button
                            className="btn btn-sm btn-outline-warning me-2"
                            onClick={() => openModal('user', user)}
                            title="Edit User"
                          >
                            <i className="fas fa-edit"></i>
                          </button>
                          
                          {/* Only show admin controls if current user is admin and target user is not amielverzola@gmail.com */}
                          {currentUser?.role === 'admin' && user.email.toLowerCase() !== 'amielverzola@gmail.com' && (
                            <>
                              {/* Role change buttons */}
                              {user.role === 'agent' ? (
                                <button
                                  className="btn btn-sm btn-outline-success me-2"
                                  onClick={() => handleRoleChange(user.id, 'admin')}
                                  title="Promote to Admin"
                                >
                                  <i className="fas fa-user-shield"></i>
                                </button>
                              ) : (
                                <button
                                  className="btn btn-sm btn-outline-primary me-2"
                                  onClick={() => handleRoleChange(user.id, 'agent')}
                                  title="Demote to Agent"
                                >
                                  <i className="fas fa-user"></i>
                                </button>
                              )}
                              
                              {/* Delete button - only for non-admin users */}
                              {user.role !== 'admin' && (
                                <button
                                  className="btn btn-sm btn-outline-danger"
                                  onClick={() => handleDelete('user', user.id)}
                                  title="Delete User"
                                >
                                  <i className="fas fa-trash"></i>
                                </button>
                              )}
                            </>
                          )}
                          
                          {/* Special indicator for amielverzola@gmail.com */}
                          {user.email.toLowerCase() === 'amielverzola@gmail.com' && (
                            <span className="badge bg-warning text-dark ms-2" title="Primary Admin - Cannot be modified">
                              <i className="fas fa-crown"></i> Primary Admin
                            </span>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* Modal */}
      {showModal && (
        <div className="modal show d-block" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog modal-lg">
            <div className="modal-content" style={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 25px rgba(0, 0, 0, 0.2)' }}>
              <div className="modal-header" style={{ background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', color: 'white', borderRadius: '12px 12px 0 0' }}>
                <h5 className="modal-title">
                  {editingItem ? 'Edit' : 'Add'} {modalType}
                </h5>
                <button type="button" className="btn-close btn-close-white" onClick={closeModal}></button>
              </div>
              <form onSubmit={handleSubmit}>
                <div className="modal-body">
                  {modalType === 'company' && (
                    <div className="row">
                      <div className="col-md-6 mb-3">
                        <label className="form-label">Company Name</label>
                        <input
                          type="text"
                          className="form-control"
                          name="name"
                          value={formData.name}
                          onChange={handleInputChange}
                          required
                        />
                      </div>
                      <div className="col-md-6 mb-3">
                        <label className="form-label">Industry</label>
                        <input
                          type="text"
                          className="form-control"
                          name="industry"
                          value={formData.industry}
                          onChange={handleInputChange}
                          required
                        />
                      </div>
                      <div className="col-md-6 mb-3">
                        <label className="form-label">Contact Person</label>
                        <input
                          type="text"
                          className="form-control"
                          name="contactPerson"
                          value={formData.contactPerson}
                          onChange={handleInputChange}
                          required
                        />
                      </div>
                      <div className="col-md-6 mb-3">
                        <label className="form-label">Phone</label>
                        <input
                          type="tel"
                          className="form-control"
                          name="phone"
                          value={formData.phone}
                          onChange={handleInputChange}
                          required
                        />
                      </div>
                      <div className="col-md-6 mb-3">
                        <label className="form-label">Email</label>
                        <input
                          type="email"
                          className="form-control"
                          name="email"
                          value={formData.email}
                          onChange={handleInputChange}
                          required
                        />
                      </div>
                      <div className="col-md-6 mb-3">
                        <label className="form-label">Website</label>
                        <input
                          type="url"
                          className="form-control"
                          name="website"
                          value={formData.website}
                          onChange={handleInputChange}
                        />
                      </div>
                      <div className="col-12 mb-3">
                        <label className="form-label">Address</label>
                        <textarea
                          className="form-control"
                          name="address"
                          rows={3}
                          value={formData.address}
                          onChange={handleInputChange}
                          required
                        ></textarea>
                      </div>
                    </div>
                  )}

                  {modalType === 'branch' && (
                    <div className="row">
                      <div className="col-md-6 mb-3">
                        <label className="form-label">Branch Name</label>
                        <input
                          type="text"
                          className="form-control"
                          name="branchName"
                          value={formData.branchName}
                          onChange={handleInputChange}
                          required
                        />
                      </div>
                      <div className="col-md-6 mb-3">
                        <label className="form-label">Company</label>
                        <select
                          className="form-select"
                          name="companyId"
                          value={formData.companyId}
                          onChange={handleInputChange}
                          required
                        >
                          <option value="">Select Company</option>
                          {companies.map(company => (
                            <option key={company.id} value={company.id}>{company.name}</option>
                          ))}
                        </select>
                      </div>
                      <div className="col-md-6 mb-3">
                        <label className="form-label">Contact Person</label>
                        <input
                          type="text"
                          className="form-control"
                          name="branchContactPerson"
                          value={formData.branchContactPerson}
                          onChange={handleInputChange}
                          required
                        />
                      </div>
                      <div className="col-md-6 mb-3">
                        <label className="form-label">Phone</label>
                        <input
                          type="tel"
                          className="form-control"
                          name="branchPhone"
                          value={formData.branchPhone}
                          onChange={handleInputChange}
                          required
                        />
                      </div>
                      <div className="col-md-6 mb-3">
                        <label className="form-label">Email</label>
                        <input
                          type="email"
                          className="form-control"
                          name="branchEmail"
                          value={formData.branchEmail}
                          onChange={handleInputChange}
                          required
                        />
                      </div>
                      <div className="col-12 mb-3">
                        <label className="form-label">Address</label>
                        <textarea
                          className="form-control"
                          name="branchAddress"
                          rows={3}
                          value={formData.branchAddress}
                          onChange={handleInputChange}
                          required
                        ></textarea>
                      </div>
                    </div>
                  )}

                  {modalType === 'user' && (
                    <div className="row">
                      <div className="col-md-6 mb-3">
                        <label className="form-label">Username</label>
                        <input
                          type="text"
                          className="form-control"
                          name="username"
                          value={formData.username}
                          onChange={handleInputChange}
                          required
                        />
                      </div>
                      <div className="col-md-6 mb-3">
                        <label className="form-label">Email</label>
                        <input
                          type="email"
                          className="form-control"
                          name="userEmail"
                          value={formData.userEmail}
                          onChange={handleInputChange}
                          required
                        />
                      </div>
                      <div className="col-md-6 mb-3">
                        <label className="form-label">First Name</label>
                        <input
                          type="text"
                          className="form-control"
                          name="firstName"
                          value={formData.firstName}
                          onChange={handleInputChange}
                          required
                        />
                      </div>
                      <div className="col-md-6 mb-3">
                        <label className="form-label">Last Name</label>
                        <input
                          type="text"
                          className="form-control"
                          name="lastName"
                          value={formData.lastName}
                          onChange={handleInputChange}
                          required
                        />
                      </div>
                      {/* Only show role selection to admins and prevent setting admin role unless user is amielverzola@gmail.com */}
                      {currentUser?.role === 'admin' && (
                        <div className="col-md-6 mb-3">
                          <label className="form-label">Role</label>
                          <select
                            className="form-select"
                            name="role"
                            value={formData.role}
                            onChange={handleInputChange}
                            required
                          >
                            <option value="agent">Agent</option>
                            {/* Only amielverzola@gmail.com can assign admin roles */}
                            {currentUser?.email?.toLowerCase() === 'amielverzola@gmail.com' && (
                              <option value="admin">Admin</option>
                            )}
                          </select>
                          {currentUser?.email?.toLowerCase() !== 'amielverzola@gmail.com' && (
                            <small className="text-muted">Only the primary admin can assign admin roles</small>
                          )}
                        </div>
                      )}
                      
                      {/* Non-admins see read-only role field */}
                      {currentUser?.role !== 'admin' && (
                        <div className="col-md-6 mb-3">
                          <label className="form-label">Role</label>
                          <input
                            type="text"
                            className="form-control"
                            value="Agent"
                            disabled
                            title="Role is automatically set to Agent"
                          />
                          <small className="text-muted">New users are automatically assigned Agent role</small>
                        </div>
                      )}
                      <div className="col-md-6 mb-3">
                        <label className="form-label">Department</label>
                        <input
                          type="text"
                          className="form-control"
                          name="department"
                          value={formData.department}
                          onChange={handleInputChange}
                          required
                        />
                      </div>
                      <div className="col-12 mb-3">
                        <label className="form-label">
                          Password {editingItem && <small className="text-muted">(Leave blank to keep current password)</small>}
                        </label>
                        <input
                          type="password"
                          className="form-control"
                          name="password"
                          value={formData.password}
                          onChange={handleInputChange}
                          required={!editingItem}
                        />
                      </div>
                    </div>
                  )}
                </div>
                <div className="modal-footer">
                  <button type="button" className="btn btn-secondary" onClick={closeModal}>
                    Cancel
                  </button>
                  <button 
                    type="submit" 
                    className="btn btn-primary"
                    disabled={loading}
                    style={{ background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', border: 'none' }}
                  >
                    {loading ? (
                      <>
                        <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                        Saving...
                      </>
                    ) : (
                      <>
                        <i className="fas fa-save me-2"></i>
                        {editingItem ? 'Update' : 'Create'}
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}


    </main>
  );
};

export default Setup; 