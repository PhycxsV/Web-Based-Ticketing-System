import React, { useState } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import toast from 'react-hot-toast';
import emailjs from '@emailjs/browser';

const Login: React.FC = () => {
  const { login, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [activeForm, setActiveForm] = useState('login');
  const [generatedOTP, setGeneratedOTP] = useState('');
  const [isOTPSending, setIsOTPSending] = useState(false);
  const [formData, setFormData] = useState({
    identifier: '',
    password: '',
    firstName: '',
    lastName: '',
    email: '',
    confirmPassword: '',
    otp: ''
  });

  // Initialize EmailJS
  React.useEffect(() => {
    emailjs.init('ToriJv6a4177MZcS-'); // Your public key
  }, []);

  // Don't auto-redirect - let user manually login each time for security
  if (isAuthenticated) {
    return <Navigate to="/dashboard" replace />;
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    const success = await login(formData.identifier, formData.password);
    if (success) {
      // Use React Router navigation for smooth redirect
      setTimeout(() => {
        navigate('/dashboard');
      }, 100); // Small delay to ensure auth state is updated
    }
  };

  const generateOTP = () => {
    return Math.floor(100000 + Math.random() * 900000).toString(); // 6-digit OTP
  };

  const sendOTPEmail = async (email: string, firstName: string, lastName: string, otp: string) => {
    try {
      const templateParams = {
        to_email: email,
        to_name: `${firstName} ${lastName}`,
        otp_code: otp,
        from_name: 'WorkSync Team'
      };

      await emailjs.send(
        'service_9oxxrmg',    // Your service ID
        'template_qp1q958',   // Your template ID
        templateParams
      );

      return true;
    } catch (error) {
      console.error('EmailJS Error:', error);
      return false;
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.firstName || !formData.lastName || !formData.email || !formData.password || !formData.confirmPassword) {
      toast.error('Please fill in all required fields');
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      toast.error('Passwords do not match');
      return;
    }

    if (formData.password.length < 6) {
      toast.error('Password must be at least 6 characters long');
      return;
    }

    setIsOTPSending(true);
    
    // Generate OTP
    const otp = generateOTP();
    setGeneratedOTP(otp);

    // Send OTP via EmailJS
    const emailSent = await sendOTPEmail(formData.email, formData.firstName, formData.lastName, otp);
    
    setIsOTPSending(false);

    if (emailSent) {
      setActiveForm('otp');
      toast.success(`OTP sent to ${formData.email}`);
    } else {
      toast.error('Failed to send OTP. Please try again.');
    }
  };

  const handleOTP = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.otp) {
      toast.error('Please enter the OTP');
      return;
    }

    if (formData.otp !== generatedOTP) {
      toast.error('Invalid OTP. Please check and try again.');
      return;
    }

    try {
      // Register the user with the backend
      const response = await fetch('http://localhost:1337/api/auth/local/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          username: formData.email, // Use email as username
          email: formData.email,
          password: formData.password,
          firstName: formData.firstName,
          lastName: formData.lastName,
          role: 'agent'
        }),
      });

      const data = await response.json();

      if (response.ok && data.success) {
        toast.success('Registration successful! Please login with your credentials.');
        
        // Reset form and go back to login
        setFormData({
          identifier: '',
          password: '',
          firstName: '',
          lastName: '',
          email: '',
          confirmPassword: '',
          otp: ''
        });
        setGeneratedOTP('');
        setActiveForm('login');
      } else {
        toast.error(data.message || 'Registration failed. Please try again.');
      }
      
    } catch (error) {
      console.error('Registration error:', error);
      toast.error('Registration failed. Please try again.');
    }
  };

  const resendOTP = async () => {
    setIsOTPSending(true);
    
    const otp = generateOTP();
    setGeneratedOTP(otp);

    const emailSent = await sendOTPEmail(formData.email, formData.firstName, formData.lastName, otp);
    
    setIsOTPSending(false);

    if (emailSent) {
      toast.success('New OTP sent to your email');
    } else {
      toast.error('Failed to resend OTP. Please try again.');
    }
  };

  return (
    <main>
      <section className="login-section" style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#f8f9fa' }}>
        <div className="login-wrapper" style={{ background: 'white', padding: '3rem', borderRadius: '12px', boxShadow: '0 10px 25px rgba(0,0,0,0.1)', width: '100%', maxWidth: '400px' }}>
          <div className="text-center mb-4">
            <img src="/images/logo/favicon.png" className="login-logo" alt="WorkSync Logo" style={{ width: '80px', height: '80px' }} />
          </div>

          <div className="form-container" style={{ position: 'relative', minHeight: '500px' }}>
            {/* LOGIN FORM */}
            {activeForm === 'login' && (
              <div className="login-form">
                <h5 className="form-title mb-2">WorkSync Login</h5>
                <p className="form-subtitle text-muted mb-4">Enter your email/username and password to sign in</p>

                <form onSubmit={handleLogin} autoComplete="off">
                  <div className="mb-3">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Enter Email or Username"
                      name="identifier"
                      value={formData.identifier}
                      onChange={handleInputChange}
                      autoComplete="off"
                      required
                    />
                  </div>

                  <div className="mb-3">
                    <input
                      type="password"
                      className="form-control"
                      placeholder="Password"
                      name="password"
                      value={formData.password}
                      onChange={handleInputChange}
                      autoComplete="new-password"
                      required
                    />
                  </div>

                  <div className="text-end mb-3">
                    <button type="button" className="btn btn-link btn-forgot-psw text-decoration-none p-0" style={{ fontSize: '0.9rem' }}>
                      Forgot Password?
                    </button>
                  </div>

                  <button
                    type="submit"
                    className="btn btn-primary w-100 mt-4"
                    style={{ background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', border: 'none', padding: '0.75rem' }}
                  >
                    <i className="fas fa-sign-in-alt me-2"></i>Login
                  </button>
                </form>
                
                <div className="form-toggle text-center mt-4">
                  <p>Don't have an account? <button type="button" onClick={() => setActiveForm('register')} className="btn btn-link text-decoration-none p-0">Create Account</button></p>
                </div>
              </div>
            )}

            {/* REGISTER FORM */}
            {activeForm === 'register' && (
              <div className="register-form">
                <h5 className="form-title mb-2">Create Account</h5>
                <p className="form-subtitle text-muted mb-4">Fill in your details to create a new account</p>

                <form onSubmit={handleRegister} autoComplete="off">
                  <div className="row mb-3">
                    <div className="col-md-6">
                      <input
                        type="text"
                        className="form-control"
                        placeholder="First Name"
                        name="firstName"
                        value={formData.firstName}
                        onChange={handleInputChange}
                        autoComplete="off"
                        required
                      />
                    </div>
                    <div className="col-md-6">
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Last Name"
                        name="lastName"
                        value={formData.lastName}
                        onChange={handleInputChange}
                        autoComplete="off"
                        required
                      />
                    </div>
                  </div>

                  <div className="mb-3">
                    <input
                      type="email"
                      className="form-control"
                      placeholder="Email Address"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      autoComplete="off"
                      required
                    />
                  </div>

                  <div className="mb-3">
                    <input
                      type="password"
                      className="form-control"
                      placeholder="Password"
                      name="password"
                      value={formData.password}
                      onChange={handleInputChange}
                      autoComplete="new-password"
                      required
                    />
                  </div>

                  <div className="mb-3">
                    <input
                      type="password"
                      className="form-control"
                      placeholder="Confirm Password"
                      name="confirmPassword"
                      value={formData.confirmPassword}
                      onChange={handleInputChange}
                      autoComplete="new-password"
                      required
                    />
                  </div>

                  <button
                    type="submit"
                    className="btn btn-primary w-100 mt-4"
                    style={{ background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', border: 'none', padding: '0.75rem' }}
                    disabled={isOTPSending}
                  >
                    {isOTPSending ? (
                      <>
                        <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                        Sending...
                      </>
                    ) : (
                      <>
                        <i className="fas fa-paper-plane me-2"></i>Send OTP
                      </>
                    )}
                  </button>
                </form>
                
                <div className="form-toggle text-center mt-4">
                  <p>Already have an account? <button type="button" onClick={() => setActiveForm('login')} className="btn btn-link text-decoration-none p-0">Sign In</button></p>
                </div>
              </div>
            )}

            {/* OTP FORM */}
            {activeForm === 'otp' && (
              <div className="otp-form">
                <h5 className="form-title mb-2">Verify OTP</h5>
                <p className="form-subtitle text-muted mb-4">Enter the OTP sent to your email</p>

                <div className="otp-info p-3 mb-4" style={{ background: '#e7f3ff', border: '1px solid #b6d7ff', borderRadius: '8px', color: '#0066cc' }}>
                  <i className="fas fa-info-circle me-2"></i>
                  We've sent a verification code to your email address.
                </div>

                <form onSubmit={handleOTP} autoComplete="off">
                  <div className="mb-3">
                    <input
                      type="text"
                      className="form-control otp-input text-center"
                      placeholder="Enter OTP"
                      name="otp"
                      value={formData.otp}
                      onChange={handleInputChange}
                      autoComplete="off"
                      style={{ fontSize: '1.5rem', fontWeight: 'bold', letterSpacing: '0.5rem' }}
                      required
                    />
                  </div>

                  <button
                    type="submit"
                    className="btn btn-primary w-100 mt-4"
                    style={{ background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', border: 'none', padding: '0.75rem' }}
                  >
                    <i className="fas fa-check me-2"></i>Verify OTP
                  </button>
                </form>
                
                <div className="text-center mt-3">
                  <button 
                    type="button"
                    className="btn btn-link resend-otp text-decoration-none p-0" 
                    style={{ fontSize: '0.9rem' }}
                    onClick={resendOTP}
                    disabled={isOTPSending}
                  >
                    {isOTPSending ? 'Sending...' : 'Resend OTP'}
                  </button>
                </div>
                
                <div className="form-toggle text-center mt-4">
                  <p>Want to try a different email? <button type="button" onClick={() => setActiveForm('register')} className="btn btn-link text-decoration-none p-0">Go Back</button></p>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>
    </main>
  );
};

export default Login; 