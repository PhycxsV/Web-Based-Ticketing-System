import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Navbar from '../components/Navbar';
import { useAuth } from '../contexts/AuthContext';
import axios from 'axios';

interface DashboardStats {
  totalTickets: number;
  totalCompanies: number;
  pendingTickets: number;
  resolvedTickets: number;
  highPriorityTickets: number;
  avgResolutionTime: string;
}

interface Ticket {
  id: number;
  ticketNumber: string;
  title: string;
  priority: string;
  status: string;
  company: string;
  dateCreated: string;
}

const Dashboard: React.FC = () => {
  const { token, user } = useAuth();
  const navigate = useNavigate();
  
  // Debug: Check user role
  console.log('Dashboard - Current user:', user);
  console.log('Dashboard - User role:', user?.role);
  
  const [stats, setStats] = useState<DashboardStats>({
    totalTickets: 0,
    totalCompanies: 0,
    pendingTickets: 0,
    resolvedTickets: 0,
    highPriorityTickets: 0,
    avgResolutionTime: '0h'
  });
  const [recentTickets, setRecentTickets] = useState<Ticket[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
    
    // Set up periodic refresh every 30 seconds to catch new tickets
    const interval = setInterval(() => {
      fetchDashboardData();
    }, 30000);
    
    return () => clearInterval(interval);
  }, []);

  const getAuthHeaders = () => ({
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    }
  });

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      
      // Fetch dashboard analytics from the backend
      const [statsResponse, ticketsResponse] = await Promise.all([
        axios.get('http://localhost:1337/api/reports/dashboard', getAuthHeaders()),
        axios.get('http://localhost:1337/api/tickets?limit=5&sort=dateCreated:desc', getAuthHeaders())
      ]);

      setStats(statsResponse.data);
      setRecentTickets(ticketsResponse.data.slice(0, 5)); // Take only first 5 for recent tickets
      
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
      // Fallback to basic stats if API fails
      try {
        const [companiesResponse, ticketsResponse] = await Promise.all([
          axios.get('http://localhost:1337/api/companies', getAuthHeaders()),
          axios.get('http://localhost:1337/api/tickets', getAuthHeaders())
        ]);

        const tickets = ticketsResponse.data;
        const companies = companiesResponse.data;

        // Ensure all tickets have a status (default to 'open' if not set)
        const processedTickets = tickets.map((ticket: any) => ({
          ...ticket,
          status: ticket.status || 'open'
        }));

        setStats({
          totalTickets: processedTickets.length,
          totalCompanies: companies.length,
          pendingTickets: processedTickets.filter((t: any) => t.status === 'open' || t.status === 'in-progress').length,
          resolvedTickets: processedTickets.filter((t: any) => t.status === 'resolved').length,
          highPriorityTickets: processedTickets.filter((t: any) => t.priority === 'high').length,
          avgResolutionTime: '2.5h'
        });

        // Ensure recent tickets also have proper status
        const recentTicketsWithStatus = processedTickets
          .sort((a: any, b: any) => new Date(b.dateCreated).getTime() - new Date(a.dateCreated).getTime())
          .slice(0, 5)
          .map((ticket: any) => ({
            ...ticket,
            status: ticket.status || 'open'
          }));

        setRecentTickets(recentTicketsWithStatus);
      } catch (fallbackError) {
        console.error('Error fetching fallback data:', fallbackError);
      }
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString: string) => {
    try {
      return new Date(dateString).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      });
    } catch (error) {
      return 'Invalid Date';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'text-danger';
      case 'medium': return 'text-warning';
      case 'low': return 'text-success';
      default: return 'text-secondary';
    }
  };

  const getStatusBadge = (status: string) => {
    const badgeClasses = {
      'open': 'bg-warning text-dark',
      'in-progress': 'bg-info text-white',
      'resolved': 'bg-success text-white',
      'closed': 'bg-secondary text-white'
    };
    return badgeClasses[status as keyof typeof badgeClasses] || 'bg-secondary text-white';
  };

  if (loading) {
    return (
      <div className="d-flex justify-content-center align-items-center" style={{ minHeight: '100vh' }}>
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }

  return (
    <main style={{ backgroundColor: '#f8f9fa', minHeight: '100vh' }}>
      <Navbar />
      
      {/* Dashboard Header */}
      <div className="dashboard-header" style={{ background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', color: 'white', padding: '2rem 0', marginBottom: '2rem' }}>
        <div className="container">
          <div className="d-flex justify-content-between align-items-center">
            <div>
              <h1 className="mb-0">Dashboard</h1>
              <p className="mb-0">Welcome to your WorkSync dashboard</p>
            </div>
            <button 
              className="btn btn-outline-light"
              onClick={fetchDashboardData}
            >
              <i className="fas fa-sync me-2"></i>Refresh Data
            </button>
          </div>
        </div>
      </div>

      <div className="container">
        {/* Statistics Cards */}
        <div className="row mb-4">
          <div className="col-lg-2 col-md-4 col-sm-6 mb-3">
            <div className="stat-card" style={{ background: 'white', borderRadius: '12px', padding: '1.5rem', boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)', borderLeft: '4px solid #28a745', height: '120px', display: 'flex', alignItems: 'center' }}>
              <div className="flex-grow-1">
                <div className="stat-number" style={{ fontSize: '2rem', fontWeight: 'bold', marginBottom: '0.25rem' }}>{stats.totalTickets}</div>
                <div className="stat-label" style={{ color: '#6c757d', fontSize: '0.85rem' }}>Total Tickets</div>
              </div>
              <i className="fas fa-ticket-alt" style={{ fontSize: '2rem', color: '#28a745' }}></i>
            </div>
          </div>
          
          <div className="col-lg-2 col-md-4 col-sm-6 mb-3">
            <div className="stat-card" style={{ background: 'white', borderRadius: '12px', padding: '1.5rem', boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)', borderLeft: '4px solid #007bff', height: '120px', display: 'flex', alignItems: 'center' }}>
              <div className="flex-grow-1">
                <div className="stat-number" style={{ fontSize: '2rem', fontWeight: 'bold', marginBottom: '0.25rem' }}>{stats.totalCompanies}</div>
                <div className="stat-label" style={{ color: '#6c757d', fontSize: '0.85rem' }}>Companies</div>
              </div>
              <i className="fas fa-building" style={{ fontSize: '2rem', color: '#007bff' }}></i>
            </div>
          </div>
          
          <div className="col-lg-2 col-md-4 col-sm-6 mb-3">
            <div className="stat-card" style={{ background: 'white', borderRadius: '12px', padding: '1.5rem', boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)', borderLeft: '4px solid #ffc107', height: '120px', display: 'flex', alignItems: 'center' }}>
              <div className="flex-grow-1">
                <div className="stat-number" style={{ fontSize: '2rem', fontWeight: 'bold', marginBottom: '0.25rem' }}>{stats.pendingTickets}</div>
                <div className="stat-label" style={{ color: '#6c757d', fontSize: '0.85rem' }}>Pending</div>
              </div>
              <i className="fas fa-clock" style={{ fontSize: '2rem', color: '#ffc107' }}></i>
            </div>
          </div>
          
          <div className="col-lg-2 col-md-4 col-sm-6 mb-3">
            <div className="stat-card" style={{ background: 'white', borderRadius: '12px', padding: '1.5rem', boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)', borderLeft: '4px solid #6f42c1', height: '120px', display: 'flex', alignItems: 'center' }}>
              <div className="flex-grow-1">
                <div className="stat-number" style={{ fontSize: '2rem', fontWeight: 'bold', marginBottom: '0.25rem' }}>{stats.resolvedTickets}</div>
                <div className="stat-label" style={{ color: '#6c757d', fontSize: '0.85rem' }}>Resolved</div>
              </div>
              <i className="fas fa-check-circle" style={{ fontSize: '2rem', color: '#6f42c1' }}></i>
            </div>
          </div>
          
          <div className="col-lg-2 col-md-4 col-sm-6 mb-3">
            <div className="stat-card" style={{ background: 'white', borderRadius: '12px', padding: '1.5rem', boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)', borderLeft: '4px solid #dc3545', height: '120px', display: 'flex', alignItems: 'center' }}>
              <div className="flex-grow-1">
                <div className="stat-number" style={{ fontSize: '2rem', fontWeight: 'bold', marginBottom: '0.25rem' }}>{stats.highPriorityTickets}</div>
                <div className="stat-label" style={{ color: '#6c757d', fontSize: '0.85rem' }}>High Priority</div>
              </div>
              <i className="fas fa-exclamation-triangle" style={{ fontSize: '2rem', color: '#dc3545' }}></i>
            </div>
          </div>
          
          <div className="col-lg-2 col-md-4 col-sm-6 mb-3">
            <div className="stat-card" style={{ background: 'white', borderRadius: '12px', padding: '1.5rem', boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)', borderLeft: '4px solid #17a2b8', height: '120px', display: 'flex', alignItems: 'center' }}>
              <div className="flex-grow-1">
                <div className="stat-number" style={{ fontSize: '2rem', fontWeight: 'bold', marginBottom: '0.25rem' }}>{stats.avgResolutionTime}</div>
                <div className="stat-label" style={{ color: '#6c757d', fontSize: '0.85rem' }}>Avg Resolution</div>
              </div>
              <i className="fas fa-stopwatch" style={{ fontSize: '2rem', color: '#17a2b8' }}></i>
            </div>
          </div>
        </div>

        <div className="row">
          {/* Recent Tickets */}
          <div className="col-lg-8 mb-4">
            <div className="data-table" style={{ background: 'white', borderRadius: '12px', boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)', overflow: 'hidden' }}>
              <div className="table-header" style={{ background: '#f8f9fa', padding: '1rem 1.5rem', borderBottom: '1px solid #dee2e6', fontWeight: 600 }}>
                <i className="fas fa-list me-2"></i>Recent Tickets
              </div>
              <div className="table-responsive">
                <table className="table table-hover mb-0">
                  <thead>
                    <tr>
                      <th>Ticket #</th>
                      <th>Title</th>
                      <th>Priority</th>
                      <th>Status</th>
                      <th>Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {recentTickets.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="text-center py-4 text-muted">
                          <i className="fas fa-inbox fa-2x mb-3 d-block"></i>
                          No recent tickets found
                        </td>
                      </tr>
                    ) : (
                      recentTickets.map(ticket => (
                        <tr key={ticket.id}>
                          <td className="fw-bold">{ticket.ticketNumber || 'N/A'}</td>
                          <td>{ticket.title || 'Untitled'}</td>
                          <td>
                            <span className={getPriorityColor(ticket.priority || 'low')}>
                              <i className="fas fa-circle me-1" style={{ fontSize: '0.5rem' }}></i>
                              {ticket.priority || 'low'}
                            </span>
                          </td>
                          <td>
                            <span className={`badge ${getStatusBadge(ticket.status || 'open')}`}>
                              {(ticket.status || 'open').replace('-', ' ')}
                            </span>
                          </td>
                          <td>{ticket.dateCreated ? formatDate(ticket.dateCreated) : 'N/A'}</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="col-lg-4 mb-4">
            <div className="quick-actions" style={{ background: 'white', borderRadius: '12px', padding: '1.5rem', boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)' }}>
              <h6 className="mb-3">
                <i className="fas fa-bolt me-2"></i>Quick Actions
              </h6>
              
              <div 
                className="action-btn" 
                onClick={() => navigate('/tickets')}
                style={{ 
                  display: 'flex', 
                  alignItems: 'center', 
                  padding: '0.75rem 1rem', 
                  marginBottom: '0.5rem', 
                  borderRadius: '8px', 
                  cursor: 'pointer', 
                  color: '#495057', 
                  transition: 'background-color 0.2s',
                  background: 'transparent',
                  border: 'none'
                }}
                onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#f8f9fa'}
                onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
              >
                <i className="fas fa-ticket-alt me-3 text-primary"></i>
                <div>
                  <div className="fw-bold">{user?.role === 'admin' ? 'Manage Tickets' : 'View Tickets'}</div>
                  <small className="text-muted">{user?.role === 'admin' ? 'Create, edit, and manage tickets' : 'View and track ticket status'}</small>
                </div>
              </div>
              
              {/* Admin-only actions */}
              {user?.role === 'admin' && (
                <>
                  <div 
                    className="action-btn" 
                    onClick={() => navigate('/setup')}
                    style={{ 
                      display: 'flex', 
                      alignItems: 'center', 
                      padding: '0.75rem 1rem', 
                      marginBottom: '0.5rem', 
                      borderRadius: '8px', 
                      cursor: 'pointer', 
                      color: '#495057', 
                      transition: 'background-color 0.2s',
                      background: 'transparent',
                      border: 'none'
                    }}
                    onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#f8f9fa'}
                    onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                  >
                    <i className="fas fa-building me-3 text-success"></i>
                    <div>
                      <div className="fw-bold">Manage Companies</div>
                      <small className="text-muted">Add or edit company information</small>
                    </div>
                  </div>
                  
                  <div 
                    className="action-btn" 
                    onClick={() => navigate('/setup')}
                    style={{ 
                      display: 'flex', 
                      alignItems: 'center', 
                      padding: '0.75rem 1rem', 
                      marginBottom: '0.5rem', 
                      borderRadius: '8px', 
                      cursor: 'pointer', 
                      color: '#495057', 
                      transition: 'background-color 0.2s',
                      background: 'transparent',
                      border: 'none'
                    }}
                    onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#f8f9fa'}
                    onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                  >
                    <i className="fas fa-users me-3 text-warning"></i>
                    <div>
                      <div className="fw-bold">Manage Users</div>
                      <small className="text-muted">Add or edit user accounts</small>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </main>
  );
};

export default Dashboard; 