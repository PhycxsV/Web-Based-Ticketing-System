import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

const Navbar: React.FC = () => {
  const { user, logout } = useAuth();
  const location = useLocation();
  
  // Debug: Check user role
  console.log('Navbar - Current user:', user);
  console.log('Navbar - User role:', user?.role);

  const isActive = (path: string) => {
    return location.pathname === path ? 'nav-link active' : 'nav-link';
  };

  return (
    <nav className="navbar navbar-expand-lg" style={{ background: 'white', boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)', padding: '1rem 0' }}>
      <div className="container-fluid">
        <Link className="navbar-brand" to="/dashboard">
          <img src="/images/logo/favicon.png" width="40" height="40" alt="WorkSync Logo" />
          <span className="ms-2 fw-bold text-primary">WorkSync</span>
        </Link>
        
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        
        <div className="collapse navbar-collapse" id="navbarSupportedContent">
          <ul className="navbar-nav me-auto mb-2 px-3 mb-lg-0">
            <li className="nav-item">
              <Link className={isActive('/dashboard')} to="/dashboard">
                <i className="fas fa-tachometer-alt me-2"></i>Dashboard
              </Link>
            </li>
            <li className="nav-item">
              <Link className={isActive('/tickets')} to="/tickets">
                <i className="fas fa-ticket-alt me-2"></i>
                {user?.role === 'admin' ? 'Ticket Management' : 'View Tickets'}
              </Link>
            </li>
            {/* Setup page is admin-only */}
            {user?.role === 'admin' && (
              <li className="nav-item">
                <Link className={isActive('/setup')} to="/setup">
                  <i className="fas fa-cog me-2"></i>Setup
                </Link>
              </li>
            )}
          </ul>

          <div className="d-flex align-items-center gap-3">
            <span className="text-muted">
              Welcome, <span>{user?.firstName} {user?.lastName}</span>
              {/* Show role badge for debugging */}
              <span className={`badge ms-2 ${user?.role === 'admin' ? 'bg-danger' : 'bg-primary'}`}>
                {user?.role || 'Unknown'}
              </span>
            </span>
            <div className="dropdown">
              <button
                className="btn btn-outline-primary dropdown-toggle"
                type="button"
                data-bs-toggle="dropdown"
                aria-expanded="false"
              >
                <i className="fas fa-user me-2"></i>
                {user?.username}
              </button>
              <ul className="dropdown-menu">
                <li>
                  <button className="dropdown-item" onClick={logout}>
                    <i className="fas fa-sign-out-alt me-2"></i>Logout
                  </button>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar; 