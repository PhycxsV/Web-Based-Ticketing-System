import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import toast from 'react-hot-toast';

interface User {
  id: number;
  username: string;
  email: string;
  firstName: string;
  lastName: string;
  role: string;
  department: string;
}

interface AuthContextType {
  user: User | null;
  token: string | null;
  login: (identifier: string, password: string) => Promise<boolean>;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);

  useEffect(() => {
    // Clear any stored authentication data to force login each time
    localStorage.removeItem('token');
    localStorage.removeItem('user');
  }, []);

  const validateToken = async (token: string, userData: User) => {
    try {
      const response = await fetch('http://localhost:1337/api/users/me', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });

      if (response.ok) {
        // Token is valid, set user and token
        setToken(token);
        setUser(userData);
      } else {
        // Token is invalid, clear stored data
        localStorage.removeItem('token');
        localStorage.removeItem('user');
      }
    } catch (error) {
      // Network error or token validation failed, clear stored data
      console.error('Token validation failed:', error);
      localStorage.removeItem('token');
      localStorage.removeItem('user');
    }
  };

  const login = async (identifier: string, password: string): Promise<boolean> => {
    try {
      const response = await fetch('http://localhost:1337/api/auth/local', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          identifier,
          password,
        }),
      });

      const result = await response.json();

      if (response.ok) {
        setToken(result.jwt);
        setUser(result.user);
        localStorage.setItem('token', result.jwt);
        localStorage.setItem('user', JSON.stringify(result.user));
        toast.success('Login successful!');
        return true;
      } else {
        toast.error(result.message || 'Invalid credentials');
        return false;
      }
    } catch (error) {
      toast.error('Login failed: Network error');
      return false;
    }
  };

  const logout = () => {
    setUser(null);
    setToken(null);
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    toast.success('Logged out successfully');
  };

  const value = {
    user,
    token,
    login,
    logout,
    isAuthenticated: !!user && !!token,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}; 