# WorkSync Backend API

A modern ticketing system backend built with Node.js and Express.

## 🚀 Features

- User Authentication (Login/Register)
- Company Management
- Ticket Management System
- Branch Management
- RESTful API endpoints
- CORS enabled for frontend integration

## 📋 Prerequisites

Before running this application, make sure you have:

- **Node.js** (v14 or higher)
- **npm** (v6 or higher)

## 🛠 Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/worksync.git
   cd worksync/WorkSync
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start the server**
   ```bash
   npm start
   ```

   For development with auto-restart:
   ```bash
   npm run dev
   ```

## 🌐 Server Information

- **URL**: `http://localhost:1337`
- **Default Login**:
  - Username: `worksyncmanager`
  - Password: `123123123`

## 📡 API Endpoints

### Authentication
- `POST /api/auth/local` - Login
- `POST /api/auth/local/register` - Register
- `GET /api/users/me` - Get current user

### Companies
- `GET /api/companies` - Get all companies
- `POST /api/companies` - Create company
- `PUT /api/companies/:id` - Update company
- `DELETE /api/companies/:id` - Delete company

### Tickets
- `GET /api/tickets` - Get all tickets
- `POST /api/tickets` - Create ticket
- `PUT /api/tickets/:id` - Update ticket
- `DELETE /api/tickets/:id` - Delete ticket

### Branches
- `GET /api/branches` - Get all branches
- `POST /api/branches` - Create branch
- `PUT /api/branches/:id` - Update branch
- `DELETE /api/branches/:id` - Delete branch

## 🔧 Configuration

The server runs on port `1337` by default. You can modify this in `server.js`.

## 📦 Dependencies

- `express` - Web framework
- `cors` - Cross-origin resource sharing
- `bcryptjs` - Password hashing
- `jsonwebtoken` - JWT authentication
- `body-parser` - Request body parsing

## 🚀 Deployment

For production deployment:

1. Set environment variables
2. Use a process manager like PM2
3. Configure reverse proxy (nginx)
4. Set up SSL certificates

## 👥 Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## 📄 License

This project is licensed under the ISC License. 