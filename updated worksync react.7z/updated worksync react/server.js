const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const bodyParser = require('body-parser');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 1337;
const JWT_SECRET = 'your-secret-key-change-in-production';

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const uploadDir = 'uploads/';
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname);
  }
});
const upload = multer({ storage: storage, limits: { fileSize: 10 * 1024 * 1024 } }); // 10MB limit

// Express middleware configuration
app.use(cors({
  origin: ['http://localhost:3001', 'http://localhost:3000'],
  credentials: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static('uploads')); // Serve uploaded files

// Data storage paths
const DATA_DIR = 'data';
const USERS_FILE = path.join(DATA_DIR, 'users.json');
const COMPANIES_FILE = path.join(DATA_DIR, 'companies.json');
const TICKETS_FILE = path.join(DATA_DIR, 'tickets.json');
const COMMENTS_FILE = path.join(DATA_DIR, 'comments.json');
const BRANCHES_FILE = path.join(DATA_DIR, 'branches.json');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
}

// No default users - system starts completely empty

// Data storage variables
let users = [];
let companies = [];
let tickets = [];
let comments = [];
let branches = [];

// Data persistence functions
function saveData(filename, data) {
    try {
        // Use synchronous file writing to ensure data is saved before continuing
        fs.writeFileSync(filename, JSON.stringify(data, null, 2));
        console.log(`💾 Data saved to ${filename}`);
        return true;
    } catch (error) {
        console.error(`❌ Error saving data to ${filename}:`, error);
        return false;
    }
}

function loadData(filename, defaultData = []) {
    try {
        if (fs.existsSync(filename)) {
            const data = fs.readFileSync(filename, 'utf8');
            return JSON.parse(data);
        }
        return defaultData;
    } catch (error) {
        console.error(`❌ Error loading data from ${filename}:`, error);
        return defaultData;
    }
}

// Initialize data on server start
function initializeData() {
    // Load existing data or create empty arrays - no default users
    users = loadData(USERS_FILE, []);
    companies = loadData(COMPANIES_FILE, []);
    tickets = loadData(TICKETS_FILE, []);
    comments = loadData(COMMENTS_FILE, []);
    branches = loadData(BRANCHES_FILE, []);
    
    console.log('📊 Data loaded successfully:');
    console.log(`   - Users: ${users.length}`);
    console.log(`   - Companies: ${companies.length}`);
    console.log(`   - Tickets: ${tickets.length}`);
    console.log(`   - Comments: ${comments.length}`);
    console.log(`   - Branches: ${branches.length}`);
    
    if (users.length === 0) {
        console.log('🆕 No users found - system starting fresh. Create your first account via registration.');
    }
}

// Initialize data when server starts
initializeData();

// JWT token verification middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ message: 'Access token required' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ message: 'Invalid or expired token' });
    }
    req.user = user;
    next();
  });
};

// Role-based access control middleware
const requireRole = (roles) => {
  return (req, res, next) => {
    const user = users.find(u => u.id === req.user.id);
    if (!user || !roles.includes(user.role)) {
      return res.status(403).json({ message: 'Insufficient permissions' });
    }
    next();
  };
};

// API route definitions

// Health check endpoint
app.get('/', (req, res) => {
  res.json({ message: 'WorkSync Backend API is running!', port: PORT });
});

// Authentication endpoints
app.post('/api/auth/local', async (req, res) => {
  try {
    console.log('Login attempt:', req.body);
    const { identifier, password } = req.body;
    
    if (!identifier || !password) {
      return res.status(400).json({ message: 'Username and password are required' });
    }
    
    // Searches for user by username or email
    const user = users.find(u => (u.username === identifier || u.email === identifier) && u.isActive);
    
    if (!user) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    // Check if the provided password matches the user's stored password
    const isValidPassword = password === user.password;
    
    if (!isValidPassword) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    // Creates JWT token for authenticated user
    const token = jwt.sign(
      { id: user.id, username: user.username, email: user.email, role: user.role },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    // Returns user data without password
    const { password: _, ...userWithoutPassword } = user;
    res.json({
      jwt: token,
      user: userWithoutPassword
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

app.post('/api/auth/local/register', async (req, res) => {
  try {
    const { username, email, password, firstName, lastName, role = 'agent' } = req.body;
    
    // Validates required fields
    if (!username || !email || !password || !firstName) {
      return res.status(400).json({ 
        success: false,
        message: 'Username, email, password, and first name are required'
      });
    }
    
    // Validates if user already exists
    const existingUser = users.find(u => u.username === username || u.email === email);
    if (existingUser) {
      return res.status(400).json({ 
        success: false,
        message: 'User with this username or email already exists'
      });
    }

    // For demo purposes, storing password as plain text (in production, use bcrypt)
    // const hashedPassword = await bcrypt.hash(password, 10);
    
    // Determine user role - only amielverzola@gmail.com can be admin
    // All other users are automatically set to 'agent' regardless of what they request
    let userRole = 'agent';
    if (email.toLowerCase() === 'amielverzola@gmail.com') {
      userRole = 'admin';
    }
    
    // Creates new user object
    const newUser = {
      id: users.length > 0 ? Math.max(...users.map(u => u.id)) + 1 : 1,
      username,
      email,
      password, // Using plain text for demo consistency
      firstName: firstName || '',
      lastName: lastName || '',
      role: userRole, // Use determined role, not the requested one
      isActive: true,
      department: 'General'
    };
    
    users.push(newUser);
    
    // Save users to file and check if successful
    const saveResult = saveData(USERS_FILE, users);
    
    if (!saveResult) {
      // Remove user from memory if save failed
      users.pop();
      return res.status(500).json({ 
        success: false,
        message: 'Failed to save user data. Please try again.'
      });
    }

    console.log(`✅ New user registered: ${firstName} ${lastName} (${username}) - Role: ${userRole}`);

    // Returns success without auto-login (user needs to log in manually)
    res.json({
      success: true,
      message: userRole === 'admin' 
        ? 'Admin account created successfully! You can now log in with full administrative privileges.' 
        : 'Account created successfully! You can now log in. Your account has been assigned Agent role.',
      user: {
        id: newUser.id,
        username: newUser.username,
        email: newUser.email,
        firstName: newUser.firstName,
        lastName: newUser.lastName,
        role: newUser.role
      }
    });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ 
      success: false,
      message: 'Server error during registration',
      error: error.message
    });
  }
});

app.get('/api/users/me', authenticateToken, (req, res) => {
  const user = users.find(u => u.id === req.user.id);
  if (!user) {
    return res.status(404).json({ message: 'User not found' });
  }
  
  const { password: _, ...userWithoutPassword } = user;
  res.json(userWithoutPassword);
});

// User management endpoints
app.get('/api/users', authenticateToken, requireRole(['admin']), (req, res) => {
  const usersWithoutPasswords = users.map(({ password, ...user }) => user);
  res.json(usersWithoutPasswords);
});

// Delete user endpoint (admin only)
app.delete('/api/users/:id', authenticateToken, requireRole(['admin']), (req, res) => {
  const userId = parseInt(req.params.id);
  const userIndex = users.findIndex(u => u.id === userId);
  
  if (userIndex === -1) {
    return res.status(404).json({ message: 'User not found' });
  }
  
  // Prevent deleting amielverzola@gmail.com
  if (users[userIndex].email.toLowerCase() === 'amielverzola@gmail.com') {
    return res.status(403).json({ 
      message: 'Cannot delete the primary admin account' 
    });
  }
  
  users.splice(userIndex, 1);
  saveData(USERS_FILE, users);
  res.status(204).send();
});

app.get('/api/agents', authenticateToken, (req, res) => {
  const agents = users.filter(u => u.role === 'agent' && u.isActive)
    .map(({ password, ...user }) => user);
  res.json(agents);
});

// Update user role endpoint (admin only)
app.put('/api/users/:id/role', authenticateToken, requireRole(['admin']), (req, res) => {
  const userId = parseInt(req.params.id);
  const { role } = req.body;
  
  // Find the user to update
  const userIndex = users.findIndex(u => u.id === userId);
  if (userIndex === -1) {
    return res.status(404).json({ message: 'User not found' });
  }
  
  // Prevent changing the role of amielverzola@gmail.com
  if (users[userIndex].email.toLowerCase() === 'amielverzola@gmail.com') {
    return res.status(403).json({ 
      message: 'Cannot change the role of the primary admin account' 
    });
  }
  
  // Validate role
  if (!['admin', 'agent'].includes(role)) {
    return res.status(400).json({ 
      message: 'Invalid role. Must be either "admin" or "agent"' 
    });
  }
  
  // Update user role
  users[userIndex].role = role;
  saveData(USERS_FILE, users);
  
  const { password: _, ...userWithoutPassword } = users[userIndex];
  res.json({
    message: `User role updated to ${role}`,
    user: userWithoutPassword
  });
});

// Update user information (admin only)
app.put('/api/users/:id', authenticateToken, requireRole(['admin']), (req, res) => {
  const userId = parseInt(req.params.id);
  const userData = req.body;
  
  // Find the user to update
  const userIndex = users.findIndex(u => u.id === userId);
  if (userIndex === -1) {
    return res.status(404).json({ message: 'User not found' });
  }
  
  // Prevent modifying the primary admin account
  if (users[userIndex].email.toLowerCase() === 'amielverzola@gmail.com' && req.user.email.toLowerCase() !== 'amielverzola@gmail.com') {
    return res.status(403).json({ 
      message: 'Cannot modify the primary admin account' 
    });
  }
  
  // Validate email uniqueness if email is being changed
  if (userData.email && userData.email !== users[userIndex].email) {
    const emailExists = users.find(u => u.email === userData.email && u.id !== userId);
    if (emailExists) {
      return res.status(400).json({ 
        message: 'A user with this email already exists' 
      });
    }
  }
  
  // Validate username uniqueness if username is being changed
  if (userData.username && userData.username !== users[userIndex].username) {
    const usernameExists = users.find(u => u.username === userData.username && u.id !== userId);
    if (usernameExists) {
      return res.status(400).json({ 
        message: 'A user with this username already exists' 
      });
    }
  }
  
  // Update user data (excluding sensitive fields that have separate endpoints)
  const allowedFields = ['username', 'email', 'firstName', 'lastName', 'department', 'password'];
  const updateData = {};
  
  allowedFields.forEach(field => {
    if (userData[field] !== undefined) {
      updateData[field] = userData[field];
    }
  });
  
  // Don't update password if it's empty
  if (updateData.password === '') {
    delete updateData.password;
  }
  
  // Update the user
  users[userIndex] = { ...users[userIndex], ...updateData };
  saveData(USERS_FILE, users);
  
  const { password: _, ...userWithoutPassword } = users[userIndex];
  
  console.log(`✅ User updated by admin ${req.user.username}: ${users[userIndex].firstName} ${users[userIndex].lastName}`);
  
  res.json({
    message: 'User updated successfully',
    user: userWithoutPassword
  });
});

// Company management endpoints
app.get('/api/GetCompanyList', authenticateToken, (req, res) => {
  res.json(companies);
});

app.get('/api/companies', authenticateToken, (req, res) => {
  res.json(companies);
});

app.post('/api/companies', authenticateToken, (req, res) => {
  const newCompany = {
    id: companies.length + 1,
    ...req.body,
    dateAdded: new Date().toISOString()
  };
  companies.push(newCompany);
  saveData(COMPANIES_FILE, companies);
  res.status(201).json(newCompany);
});

app.put('/api/companies/:id', authenticateToken, (req, res) => {
  const id = parseInt(req.params.id);
  const companyIndex = companies.findIndex(c => c.id === id);
  
  if (companyIndex === -1) {
    return res.status(404).json({ message: 'Company not found' });
  }
  
  companies[companyIndex] = { ...companies[companyIndex], ...req.body };
  saveData(COMPANIES_FILE, companies);
  res.json(companies[companyIndex]);
});

app.delete('/api/companies/:id', authenticateToken, (req, res) => {
  const id = parseInt(req.params.id);
  const companyIndex = companies.findIndex(c => c.id === id);
  
  if (companyIndex === -1) {
    return res.status(404).json({ message: 'Company not found' });
  }
  
  companies.splice(companyIndex, 1);
  saveData(COMPANIES_FILE, companies);
  res.status(204).send();
});

// Enhanced ticket management endpoints with search and filtering
app.get('/api/tickets', authenticateToken, (req, res) => {
  const { status, priority, assignedTo, search, category, fromDate, toDate } = req.query;
  let filteredTickets = [...tickets];

  // Apply filters
  if (status) filteredTickets = filteredTickets.filter(t => t.status === status);
  if (priority) filteredTickets = filteredTickets.filter(t => t.priority === priority);
  if (assignedTo) filteredTickets = filteredTickets.filter(t => t.assignedTo === parseInt(assignedTo));
  if (category) filteredTickets = filteredTickets.filter(t => t.category === category);
  
  // Date range filter
  if (fromDate) filteredTickets = filteredTickets.filter(t => new Date(t.dateCreated) >= new Date(fromDate));
  if (toDate) filteredTickets = filteredTickets.filter(t => new Date(t.dateCreated) <= new Date(toDate));
  
  // Search filter
  if (search) {
    const searchLower = search.toLowerCase();
    filteredTickets = filteredTickets.filter(t => 
      t.title.toLowerCase().includes(searchLower) ||
      t.description.toLowerCase().includes(searchLower) ||
      t.ticketNumber.toLowerCase().includes(searchLower) ||
      t.requestor.toLowerCase().includes(searchLower)
    );
  }

  res.json(filteredTickets);
});

app.get('/api/tickets/:id', authenticateToken, (req, res) => {
  const id = parseInt(req.params.id);
  const ticket = tickets.find(t => t.id === id);
  
  if (!ticket) {
    return res.status(404).json({ message: 'Ticket not found' });
  }
  
  res.json(ticket);
});

app.post('/api/tickets', upload.array('attachments', 5), authenticateToken, (req, res) => {
  console.log('📝 Received ticket data:', req.body);
  console.log('📁 Files received:', req.files);
  
  const newTicket = {
    id: tickets.length + 1,
    ticketNumber: `WS-2024-${String(tickets.length + 1).padStart(3, '0')}`,
    ...req.body,
    status: req.body.status || 'open', // Default status to 'open'
    dateCreated: new Date().toISOString(),
    lastUpdated: new Date().toISOString(),
    timeSpent: 0,
    attachments: [],
    category: req.body.category || 'General',
    company: req.body.company || null
  };
  
  console.log('✅ Created ticket:', newTicket);
  
  tickets.push(newTicket);
  saveData(TICKETS_FILE, tickets);
  res.status(201).json(newTicket);
});

app.put('/api/tickets/:id', authenticateToken, (req, res) => {
  const id = parseInt(req.params.id);
  const ticketIndex = tickets.findIndex(t => t.id === id);
  
  if (ticketIndex === -1) {
    return res.status(404).json({ message: 'Ticket not found' });
  }
  
  // Track status changes and resolution time
  const updatedTicket = { 
    ...tickets[ticketIndex], 
    ...req.body,
    lastUpdated: new Date().toISOString()
  };
  
  if (req.body.status === 'resolved' && tickets[ticketIndex].status !== 'resolved') {
    updatedTicket.dateResolved = new Date().toISOString();
  }
  
  tickets[ticketIndex] = updatedTicket;
  saveData(TICKETS_FILE, tickets);
  res.json(tickets[ticketIndex]);
});

app.delete('/api/tickets/:id', authenticateToken, (req, res) => {
  const id = parseInt(req.params.id);
  const ticketIndex = tickets.findIndex(t => t.id === id);
  
  if (ticketIndex === -1) {
    return res.status(404).json({ message: 'Ticket not found' });
  }
  
  tickets.splice(ticketIndex, 1);
  saveData(TICKETS_FILE, tickets);
  res.status(204).send();
});

// Ticket assignment endpoint
app.put('/api/tickets/:id/assign', authenticateToken, requireRole(['admin', 'agent']), (req, res) => {
  const id = parseInt(req.params.id);
  const { assignedTo } = req.body;
  const ticketIndex = tickets.findIndex(t => t.id === id);
  
  if (ticketIndex === -1) {
    return res.status(404).json({ message: 'Ticket not found' });
  }
  
  const agent = users.find(u => u.id === assignedTo && u.role === 'agent');
  if (!agent) {
    return res.status(400).json({ message: 'Invalid agent ID' });
  }
  
  tickets[ticketIndex].assignedTo = assignedTo;
  tickets[ticketIndex].assignedAgent = `${agent.firstName} ${agent.lastName}`;
  tickets[ticketIndex].lastUpdated = new Date().toISOString();
  
  saveData(TICKETS_FILE, tickets);
  res.json(tickets[ticketIndex]);
});

// Time tracking endpoints
app.post('/api/tickets/:id/time', authenticateToken, (req, res) => {
  const id = parseInt(req.params.id);
  const { timeSpent, description } = req.body;
  const ticketIndex = tickets.findIndex(t => t.id === id);
  
  if (ticketIndex === -1) {
    return res.status(404).json({ message: 'Ticket not found' });
  }
  
  tickets[ticketIndex].timeSpent = (tickets[ticketIndex].timeSpent || 0) + parseInt(timeSpent);
  tickets[ticketIndex].lastUpdated = new Date().toISOString();
  
  // Add time tracking comment
  const timeComment = {
    id: comments.length + 1,
    ticketId: id,
    userId: req.user.id,
    author: req.user.username,
    content: `Time logged: ${timeSpent} minutes${description ? ` - ${description}` : ''}`,
    isInternal: true,
    dateCreated: new Date().toISOString(),
    type: 'time_log'
  };
  
  comments.push(timeComment);
  saveData(TICKETS_FILE, tickets);
  saveData(COMMENTS_FILE, comments);
  
  res.json({ 
    ticket: tickets[ticketIndex],
    timeLog: timeComment
  });
});

// Comments/Communication system endpoints
app.get('/api/tickets/:id/comments', authenticateToken, (req, res) => {
  const ticketId = parseInt(req.params.id);
  const ticketComments = comments.filter(c => c.ticketId === ticketId);
  res.json(ticketComments);
});

app.post('/api/tickets/:id/comments', authenticateToken, (req, res) => {
  const ticketId = parseInt(req.params.id);
  const { content, isInternal = false } = req.body;
  const user = users.find(u => u.id === req.user.id);
  
  const newComment = {
    id: comments.length + 1,
    ticketId,
    userId: req.user.id,
    author: `${user.firstName} ${user.lastName}`,
    content,
    isInternal,
    dateCreated: new Date().toISOString(),
    type: 'comment'
  };
  
  comments.push(newComment);
  saveData(COMMENTS_FILE, comments);
  
  // Update ticket last updated time
  const ticketIndex = tickets.findIndex(t => t.id === ticketId);
  if (ticketIndex !== -1) {
    tickets[ticketIndex].lastUpdated = new Date().toISOString();
    saveData(TICKETS_FILE, tickets);
  }
  
  res.status(201).json(newComment);
});

// File upload endpoint for existing tickets
app.post('/api/tickets/:id/attachments', authenticateToken, (req, res) => {
  const ticketId = parseInt(req.params.id);
  const ticketIndex = tickets.findIndex(t => t.id === ticketId);
  
  if (ticketIndex === -1) {
    return res.status(404).json({ message: 'Ticket not found' });
  }
  
  const newAttachments = req.files.map(file => ({
    filename: file.filename,
    originalName: file.originalname,
    size: file.size,
    uploadedBy: req.user.username,
    uploadedAt: new Date().toISOString()
  }));
  
  tickets[ticketIndex].attachments = [...(tickets[ticketIndex].attachments || []), ...newAttachments];
  tickets[ticketIndex].lastUpdated = new Date().toISOString();
  
  saveData(TICKETS_FILE, tickets);
  res.json(newAttachments);
});

// Reports and analytics endpoints
app.get('/api/reports/dashboard', authenticateToken, (req, res) => {
  const totalTickets = tickets.length;
  const totalCompanies = companies.length;
  
  // Handle various status formats - both 'open' and 'in-progress', 'in_progress'
  const pendingTickets = tickets.filter(t => 
    t.status === 'open' || 
    t.status === 'in-progress' || 
    t.status === 'in_progress' ||
    !t.status // Default to pending if no status
  ).length;
  
  const resolvedTickets = tickets.filter(t => t.status === 'resolved').length;
  const highPriorityTickets = tickets.filter(t => t.priority === 'high').length;
  
  // Calculate average resolution time
  const resolvedWithTime = tickets.filter(t => t.status === 'resolved' && t.dateResolved);
  const avgResolutionHours = resolvedWithTime.length > 0 
    ? resolvedWithTime.reduce((acc, ticket) => {
        const created = new Date(ticket.dateCreated);
        const resolved = new Date(ticket.dateResolved);
        return acc + (resolved - created);
      }, 0) / resolvedWithTime.length / (1000 * 60 * 60) // Convert to hours
    : 0;
  
  const avgResolutionTime = avgResolutionHours > 0 
    ? `${Math.round(avgResolutionHours * 10) / 10}h`
    : '0h';
  
  console.log(`📊 Dashboard Stats: ${totalTickets} tickets, ${totalCompanies} companies, ${pendingTickets} pending, ${resolvedTickets} resolved, ${highPriorityTickets} high priority`);
  
  res.json({
    totalTickets,
    totalCompanies,
    pendingTickets,
    resolvedTickets,
    highPriorityTickets,
    avgResolutionTime
  });
});

// Branch management endpoints
app.get('/api/branches', authenticateToken, (req, res) => {
  res.json(branches);
});

app.post('/api/branches', authenticateToken, (req, res) => {
  const newBranch = {
    id: branches.length + 1,
    ...req.body
  };
  branches.push(newBranch);
  saveData(BRANCHES_FILE, branches);
  res.status(201).json(newBranch);
});

app.put('/api/branches/:id', authenticateToken, (req, res) => {
  const id = parseInt(req.params.id);
  const branchIndex = branches.findIndex(b => b.id === id);
  
  if (branchIndex === -1) {
    return res.status(404).json({ message: 'Branch not found' });
  }
  
  branches[branchIndex] = { ...branches[branchIndex], ...req.body };
  saveData(BRANCHES_FILE, branches);
  res.json(branches[branchIndex]);
});

app.delete('/api/branches/:id', authenticateToken, (req, res) => {
  const id = parseInt(req.params.id);
  const branchIndex = branches.findIndex(b => b.id === id);
  
  if (branchIndex === -1) {
    return res.status(404).json({ message: 'Branch not found' });
  }
  
  branches.splice(branchIndex, 1);
  saveData(BRANCHES_FILE, branches);
  res.status(204).send();
});

// Global error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ message: 'Something went wrong!', error: err.message });
});

// Starts the server
app.listen(PORT, () => {
  console.log(`
🚀 WorkSync Backend Server is running!
📍 URL: http://localhost:${PORT}
🆕 No Default Users: System starts completely empty
   Create your first account via registration at: http://localhost:3000
   
💾 Data Storage: Persistent JSON files in ./data/ folder
🗂️  Database State: All data persists across server restarts
   
📋 Available Endpoints:
   POST /api/auth/local           - Login
   POST /api/auth/local/register  - Register
   GET  /api/users/me            - Get current user
   GET  /api/users               - Get all users (admin only)
   GET  /api/agents              - Get all agents
   GET  /api/GetCompanyList      - Get companies (legacy)
   GET  /api/companies           - Get companies
   POST /api/companies           - Create company
   PUT  /api/companies/:id       - Update company
   DELETE /api/companies/:id     - Delete company
   GET  /api/tickets             - Get tickets (with filters)
   POST /api/tickets             - Create ticket (with file upload)
   PUT  /api/tickets/:id         - Update ticket
   DELETE /api/tickets/:id       - Delete ticket
   PUT  /api/tickets/:id/assign  - Assign ticket to agent
   POST /api/tickets/:id/time    - Log time to ticket
   GET  /api/tickets/:id/comments - Get ticket comments
   POST /api/tickets/:id/comments - Add comment to ticket
   POST /api/tickets/:id/attachments - Upload files to ticket
   GET  /api/reports/dashboard   - Get dashboard analytics
   GET  /api/branches            - Get branches
   POST /api/branches            - Create branch
   PUT  /api/branches/:id        - Update branch
   DELETE /api/branches/:id      - Delete branch
  `);
}); 